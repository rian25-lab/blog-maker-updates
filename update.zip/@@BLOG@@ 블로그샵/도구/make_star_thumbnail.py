#!/usr/bin/env python3
"""스타한입·@@BLOG@@ 공통 썸네일(1:1, 1080x1080) — 'S1 풀블리드 인물 뉴스형'. (--theme 로 블로그 선택)

표본: 2026-10-23 원 운영자이 첨부한 시안(밝은 인물 사진을 꽉 채우고, 왼쪽에 큰 흰 제목 2줄 + 주황 키워드 박스,
위에 작은 날짜·사실 줄, 아래 중앙에 브랜드 워드마크). 규칙 정본: 이미지외주/스타한입/스타일가이드.md '썸네일'.

사진은 **원본 그대로** 자르기·크기 조정만 한다(보정·변형·AI 재생성 없음). 이 도구가 그리는 것은
왼쪽 어두운 파랑 그라데이션(글자 가독성), 글자, 주황 박스, 워드마크뿐이다.
나쁜 이슈(사건·논란·범죄·사망 등)에는 인물 사진 썸네일을 쓰지 않는다.

사용:
  python3 make_star_thumbnail.py --photo 사진.jpg --top "10/23 멜론 발표 · 11/14~15 고척돔" \
      --title "시상자 37명,|14일? 15일?" --chip "MMA2026" --out 00_썸네일.png [--focus 0.65,0.4] [--theme star|bomi|dosolian]

  --title : '|'로 줄바꿈(2줄). 한 줄 8~12자 안팎, 앞 줄에서 훅을 끝낸다.
  --chip  : 주황 박스 키워드, 10자 이내(고유명사·행사명·작품명).
  --focus : 사진에서 얼굴(주인공) 위치(가로,세로 0~1). 이 점이 오른쪽 40% 자리에 오도록 자른다.
  --zoom  : 0.5~1.8. 1 미만은 확대(여러 명 사진에서 주인공만 남길 때), 1 초과는 축소(배경을 늘려 채움).
  --guide : 영역 가이드선을 그린 *_guide.png 를 따로 저장.
"""
import argparse, os, sys
from PIL import Image, ImageDraw, ImageFilter, ImageFont, ImageStat

S = 1080
FONT = "/System/Library/Fonts/AppleSDGothicNeo.ttc"
IDX_BLACK, IDX_BOLD = 14, 6
# 블로그별 색·워드마크. 구조·위치는 모두 같고(S1 표본), 박스 색과 하단 이름만 다르다.
THEMES = {
    "star":     dict(accent=(240, 138, 36), navy=(8, 18, 66),  boxtext=(16, 28, 60), brand="스타한입"),
    "bomi":     dict(accent=(240, 138, 36), navy=(8, 18, 66),  boxtext=(16, 28, 60), brand="@@BLOG@@"),
    "dosolian": dict(accent=(201, 164, 92), navy=(14, 30, 52), boxtext=(16, 34, 58), brand="도솔리안로그"),
}
ACCENT = THEMES["star"]["accent"]          # 주황 박스
NAVY = THEMES["star"]["navy"]              # 왼쪽 그라데이션 색
BOXTEXT = THEMES["star"]["boxtext"]
LEFT = 64


def font(size, idx=IDX_BLACK):
    try:
        return ImageFont.truetype(FONT, size, index=idx)
    except Exception:
        sys.exit("한글 폰트를 찾지 못했습니다. FONT 경로를 확인하세요.")


def brightness(path):
    """밝기 점수(0~255): 중앙 영역의 평균 명도. 자동 사진 선택에 쓴다."""
    im = Image.open(path).convert("L")
    w, h = im.size
    return ImageStat.Stat(im.crop((int(w * .15), int(h * .1), int(w * .85), int(h * .9)))).mean[0]


def cover(im, focus, zoom=1.0):
    """정사각 창을 잘라 1080으로 맞춘다. 주인공(focus)이 가로 62% 지점(오른쪽 영역)에 오도록 창을 옮긴다.
    zoom<1: 더 작은 창으로 확대(여러 명 사진에서 주인공만 남길 때, 해상도는 그만큼 줄어든다).
    zoom>1: 창을 키워 주인공을 작게 만든다(얼굴이 글자 자리까지 와 있는 사진용, 최대 1.8).
    창이 사진 밖으로 나가면 가장자리 색을 늘려 흐리게 채운다(스튜디오 흰 배경 등. 그 자리는 글자 그라데이션 아래다)."""
    w, h = im.size
    side = int(min(w, h) * zoom)
    fx, fy = focus
    left = int(fx * w - 0.62 * side)
    top = int(fy * h - 0.38 * side)
    if zoom <= 1.0:
        top = max(0, min(h - side, top))
        left = min(left, w - side)
    pl, pt = max(0, -left), max(0, -top)
    pr, pb = max(0, left + side - w), max(0, top + side - h)
    if pl or pt or pr or pb:
        # 가장자리 한 줄을 늘려 바깥을 채운 뒤 흐리게(Pillow만 사용)
        bw, bh = w + pl + pr, h + pt + pb
        big = Image.new("RGB", (bw, bh))
        big.paste(im, (pl, pt))
        if pl: big.paste(im.crop((0, 0, 1, h)).resize((pl, h)), (0, pt))
        if pr: big.paste(im.crop((w - 1, 0, w, h)).resize((pr, h)), (pl + w, pt))
        if pt: big.paste(big.crop((0, pt, bw, pt + 1)).resize((bw, pt)), (0, 0))
        if pb: big.paste(big.crop((0, pt + h - 1, bw, pt + h)).resize((bw, pb)), (0, pt + h))
        blur = big.filter(ImageFilter.GaussianBlur(16))
        blur.paste(im, (pl, pt))
        big = blur
        left, top = left + pl, top + pt
    else:
        big = im
    return big.crop((left, top, left + side, top + side)).resize((S, S), Image.LANCZOS)


def hgrad(width, a0, a1, power=1.4):
    """왼쪽 a0 → 오른쪽 a1 알파 그라데이션 마스크(1:1 크기)."""
    m = Image.new("L", (S, S), 0)
    d = ImageDraw.Draw(m)
    for x in range(S):
        t = min(1.0, x / width)
        d.line([(x, 0), (x, S)], fill=int(255 * (a0 + (a1 - a0) * (t ** power))))
    return m


def vgrad_bottom(h0, amax):
    m = Image.new("L", (S, S), 0)
    d = ImageDraw.Draw(m)
    for y in range(S):
        if y > S - h0:
            t = (y - (S - h0)) / h0
            d.line([(0, y), (S, y)], fill=int(255 * amax * t))
    return m


def shadow_text(base, xy, text, fnt, fill, anchor="la", blur=8, off=(0, 4), alpha=170):
    lay = Image.new("RGBA", base.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(lay)
    d.text((xy[0] + off[0], xy[1] + off[1]), text, font=fnt, fill=(0, 0, 20, alpha), anchor=anchor)
    lay = lay.filter(ImageFilter.GaussianBlur(blur))
    base.alpha_composite(lay)
    ImageDraw.Draw(base).text(xy, text, font=fnt, fill=fill, anchor=anchor)


def fit_size(text, idx, max_w, start, lo=40):
    size = start
    while size > lo and font(size, idx).getlength(text) > max_w:
        size -= 2
    return size


def glow_line(base, x0, x1, y):
    lay = Image.new("RGBA", base.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(lay)
    for x in range(x0, x1):
        t = (x - x0) / max(1, x1 - x0)
        a = int(230 * (1 - t) ** 0.8)
        d.line([(x, y), (x, y + 2)], fill=(255, 150, 50, a))
    glow = lay.filter(ImageFilter.GaussianBlur(5))
    base.alpha_composite(glow)
    base.alpha_composite(lay)


def make(photo, top, title, chip, out, focus=(0.6, 0.4), brand=None, guide=False, zoom=1.0, theme="star"):
    global ACCENT, NAVY, BOXTEXT
    th = THEMES.get(theme, THEMES["star"])
    ACCENT, NAVY, BOXTEXT = th["accent"], th["navy"], th["boxtext"]
    brand = th["brand"] if brand is None else brand
    im = cover(Image.open(photo).convert("RGB"), focus, zoom).convert("RGBA")
    # 전체에 옅은 파랑 톤 + 왼쪽 어두운 파랑 그라데이션(글자 영역) + 아래 어둠
    im.alpha_composite(Image.new("RGBA", (S, S), NAVY + (38,)))
    left = Image.new("RGBA", (S, S), NAVY + (255,))
    left.putalpha(hgrad(S * 0.78, 0.80, 0.0))
    im.alpha_composite(left)
    bot = Image.new("RGBA", (S, S), (0, 0, 20, 255))
    bot.putalpha(vgrad_bottom(230, 0.60))
    im.alpha_composite(bot)

    lines = [t.strip() for t in title.split("|") if t.strip()][:2]
    max_w = int(S * 0.60)
    size = min(fit_size(l, IDX_BLACK, max_w, 124) for l in lines)
    big = font(size, IDX_BLACK)
    lh = int(size * 1.14)

    # 세로 배치: 위 줄 → 가는 빛줄기 → 제목 → 빛줄기 → 박스
    top_f = font(36, IDX_BOLD)
    block_h = 44 + 30 + lh * len(lines) + 30 + 18 + 104
    y0 = int(S * 0.5 - block_h * 0.52)
    y = y0
    if top:
        tsize = fit_size(top, IDX_BOLD, int(S * 0.62), 36, 26)
        shadow_text(im, (LEFT, y), top, font(tsize, IDX_BOLD), (255, 255, 255, 235), blur=6)
    y += 44 + 12
    glow_line(im, LEFT - 8, LEFT + int(S * 0.52), y)
    y += 30
    ty = y
    for l in lines:
        shadow_text(im, (LEFT, y), l, big, (255, 255, 255, 255), blur=10, off=(0, 6), alpha=190)
        y += lh
    y += 10
    glow_line(im, LEFT - 8, LEFT + int(S * 0.52), y)
    y += 30
    if chip:
        csize = fit_size(chip, IDX_BLACK, int(S * 0.52), 80, 40)
        cf = font(csize, IDX_BLACK)
        tw = cf.getlength(chip)
        pad = 38
        d = ImageDraw.Draw(im)
        bh = int(csize * 1.42)
        d.rounded_rectangle([LEFT, y, LEFT + tw + pad * 2, y + bh], radius=20, fill=ACCENT + (255,))
        d.text((LEFT + pad, y + bh / 2 + 2), chip, font=cf, fill=BOXTEXT, anchor="lm")
        chip_bottom = y + bh
    else:
        chip_bottom = y
    if brand:
        shadow_text(im, (S // 2, S - 62), brand, font(44, IDX_BOLD), (255, 255, 255, 245), anchor="mm", blur=7)
    rgb = im.convert("RGB")
    rgb.save(out)
    if guide:
        g = rgb.copy(); gd = ImageDraw.Draw(g)
        gd.rectangle([LEFT, y0, LEFT + int(S * 0.6), chip_bottom], outline=(0, 255, 0), width=3)
        gd.rectangle([int(S * 0.55), 0, S, S - 150], outline=(255, 0, 255), width=3)   # 얼굴이 남아야 할 영역
        g.save(os.path.splitext(out)[0] + "_guide.png")
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--photo", required=True)
    ap.add_argument("--top", default="")
    ap.add_argument("--title", required=True)
    ap.add_argument("--chip", default="")
    ap.add_argument("--out", required=True)
    ap.add_argument("--focus", default="0.6,0.4")
    ap.add_argument("--theme", default="star", choices=sorted(THEMES), help="star(스타한입)·bomi(@@BLOG@@)·dosolian(도솔리안로그)")
    ap.add_argument("--brand", default=None, help="하단 워드마크(기본: 테마 이름)")
    ap.add_argument("--zoom", type=float, default=1.0, help="0.5~1.8: 작을수록 주인공 확대, 클수록 축소(배경 늘려 채움)")
    ap.add_argument("--guide", action="store_true")
    a = ap.parse_args()
    fx, fy = [float(v) for v in a.focus.split(",")]
    make(a.photo, a.top, a.title, a.chip, a.out, (fx, fy), a.brand, a.guide, a.zoom, a.theme)
    print(a.out)


if __name__ == "__main__":
    main()
