#!/usr/bin/env python3
"""홈판용 텍스트형 썸네일(1:1) 생성기.

규격(자동화/공통/이미지스타일.md): 1080x1080, 어두운 배경, 1줄=흰색 큰 굵은 고딕 인용문구, 2줄=주황 박스 핵심 대상.
글자는 중앙 70% 안에 둔다. 실존 인물 얼굴 이미지를 만들지 않는다 (배경은 생성형 보케 또는 사용자가 허용한 이미지).

사용:
  python3 make_thumbnail.py --line1 "‘저 하차합니다’" --line2 "국민 MC A씨" --out out.png [--bg 배경.jpg] [--seed 3] [--accent "#F59E0B"]
"""
import argparse, random, sys
from PIL import Image, ImageDraw, ImageFilter, ImageFont, ImageEnhance

SIZE = 1080
FONT_PATHS = [
    ("/System/Library/Fonts/AppleSDGothicNeo.ttc", 6),  # Bold
    ("/System/Library/Fonts/AppleSDGothicNeo.ttc", 4),  # SemiBold
    ("/Library/Fonts/NanumGothicBold.ttf", 0),
]

def load_font(size):
    for path, idx in FONT_PATHS:
        try:
            return ImageFont.truetype(path, size, index=idx)
        except Exception:
            continue
    sys.exit("한글 굵은 고딕 폰트를 찾지 못했습니다. FONT_PATHS를 확인하세요.")

def make_bg(seed, bg_path=None):
    if bg_path:
        im = Image.open(bg_path).convert("RGB")
        w, h = im.size; s = min(w, h)
        im = im.crop(((w - s)//2, (h - s)//2, (w - s)//2 + s, (h - s)//2 + s)).resize((SIZE, SIZE))
        im = im.filter(ImageFilter.GaussianBlur(6))
        im = ImageEnhance.Brightness(im).enhance(0.35)
        return im
    rnd = random.Random(seed)
    base = Image.new("RGB", (SIZE, SIZE), (10, 12, 22))
    d = ImageDraw.Draw(base)
    for y in range(SIZE):  # 세로 그라데이션
        t = y / SIZE
        d.line([(0, y), (SIZE, y)], fill=(int(10 + 14*t), int(12 + 10*t), int(22 + 26*t)))
    glow = Image.new("RGB", (SIZE, SIZE), (0, 0, 0))
    g = ImageDraw.Draw(glow)
    palette = [(245, 158, 11), (255, 214, 120), (90, 130, 255), (255, 110, 90), (180, 200, 255)]
    for _ in range(28):  # 보케
        r = rnd.randint(30, 110)
        x, y = rnd.randint(-30, SIZE+30), rnd.randint(-30, SIZE+30)
        c = rnd.choice(palette)
        k = rnd.uniform(0.25, 0.7)
        g.ellipse([x-r, y-r, x+r, y+r], fill=tuple(int(v*k) for v in c))
    glow = glow.filter(ImageFilter.GaussianBlur(28))
    from PIL import ImageChops
    return ImageChops.add(base, glow)

def wrap(draw, text, font, max_w):
    """'|' 로 직접 줄바꿈 지정 가능. 없으면 공백 단위로 줄바꿈하고, 한 단어가 너무 길면 글자 단위."""
    if "|" in text:
        return [t.strip() for t in text.split("|") if t.strip()]
    lines, cur = [], ""
    for word in text.split(" "):
        trial = (cur + " " + word).strip()
        if draw.textlength(trial, font=font) <= max_w:
            cur = trial
            continue
        if cur:
            lines.append(cur); cur = ""
        if draw.textlength(word, font=font) <= max_w:
            cur = word
        else:
            for ch in word:
                if draw.textlength(cur + ch, font=font) <= max_w: cur += ch
                else: lines.append(cur); cur = ch
    if cur: lines.append(cur)
    return lines

def stroke_text(draw, xy, text, font, fill, stroke=6):
    draw.text(xy, text, font=font, fill=fill, stroke_width=stroke, stroke_fill=(0, 0, 0))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--line1", required=True, help="1줄: 인용형 문구, 공백 포함 12자 안팎. '|'로 줄바꿈 지정 가능")
    ap.add_argument("--line2", required=True, help="2줄: 핵심 대상 이름, 10자 이내")
    ap.add_argument("--out", required=True)
    ap.add_argument("--bg"); ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--accent", default="#F59E0B")
    a = ap.parse_args()

    if len(a.line1.replace('|','')) > 16: print(f"[경고] 1줄이 {len(a.line1)}자입니다. 12자 안팎 권장.", file=sys.stderr)
    if len(a.line2) > 10: print(f"[경고] 2줄이 {len(a.line2)}자입니다. 10자 이내 권장.", file=sys.stderr)

    img = make_bg(a.seed, a.bg)
    d = ImageDraw.Draw(img)
    safe_w = int(SIZE * 0.70)  # 중앙 70% 안에 글자
    f1 = load_font(128)
    lines = wrap(d, a.line1, f1, safe_w)
    while len(lines) > 3 and f1.size > 80:
        f1 = load_font(f1.size - 8); lines = wrap(d, a.line1, f1, safe_w)
    f2 = load_font(96)
    while d.textlength(a.line2, font=f2) > safe_w - 80 and f2.size > 50:
        f2 = load_font(f2.size - 6)

    lh = int(f1.size * 1.2)
    box_h = int(f2.size * 1.5)
    gap = 56
    total = lh * len(lines) + gap + box_h
    y = (SIZE - total) // 2
    for ln in lines:
        w = d.textlength(ln, font=f1)
        stroke_text(d, ((SIZE - w)//2, y), ln, f1, (255, 255, 255)); y += lh
    y += gap
    tw = d.textlength(a.line2, font=f2)
    bw = int(tw + 80)
    x0 = (SIZE - bw)//2
    d.rectangle([x0, y, x0 + bw, y + box_h], fill=a.accent)
    d.text(((SIZE - tw)//2, y + (box_h - f2.size)//2 - 4), a.line2, font=f2, fill=(20, 20, 20))
    img.save(a.out)
    print("저장:", a.out)

if __name__ == "__main__":
    main()
