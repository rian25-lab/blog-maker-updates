#!/usr/bin/env python3
"""P4 인물 뉴스형 썸네일(1:1, 1080x1080) 합성기 — 방법 A.

인물 사진은 **원본 그대로** 위쪽에 얹는다(자르기·크기 조정만. 보정·변형·AI 재생성 없음).
배경(남색+좌우 빛), 사진 아래 그라데이션, 글자, 워드마크만 이 도구가 그린다.
규칙: 호재성 이슈에만 쓴다. 나쁜 이슈(사건·논란·범죄·사망 등)에는 쓰지 않는다.
(2026-10-20 원 운영자 결정. 상세: 이미지외주/<블로그>/스타일가이드.md P4)

사용:
  python3 make_portrait_thumbnail.py --photo 원본.jpg --top "10/20 보그 보도" \
      --title "11월 미국 예정이던|결혼식, 한 달 앞당겼다" --tag "케데헌 이재" \
      --out out.png [--theme bomi|dosolian] [--brand @@BLOG@@] [--focus 0.5,0.35]

  --title : '|'로 줄바꿈(2줄 권장). 한 줄 13자 안팎.
  --tag   : 주황(또는 금) 박스 키워드, 10자 이내.
  --focus : 얼굴 중심 위치(원본 가로,세로 비율 0~1). 자를 때 이 점이 사진 영역 안에 남게 한다.
  --check : 얼굴·글자 겹침 확인용 가이드선(영역 경계)을 그려 *_guide.png로 따로 저장.
"""
import argparse, sys, os
from PIL import Image, ImageDraw, ImageFilter, ImageFont, ImageChops

S = 1080
FONT = "/System/Library/Fonts/AppleSDGothicNeo.ttc"
IDX_BLACK, IDX_BOLD = 14, 6   # ExtraBold, Bold

THEMES = {
    # base: 바탕 남색, glowL/glowR: 좌우 빛, accent: 박스색, boxtext: 박스 글자색
    "bomi":     dict(base=(10, 20, 48), glowL=(40, 110, 255), glowR=(255, 130, 30),
                     accent=(240, 138, 36), boxtext=(16, 28, 60), brand="@@BLOG@@"),
    "dosolian": dict(base=(14, 30, 52), glowL=(60, 110, 190), glowR=(201, 164, 92),
                     accent=(201, 164, 92), boxtext=(16, 34, 58), brand="도솔리안로그"),
}

def font(size, idx=IDX_BLACK):
    try:
        return ImageFont.truetype(FONT, size, index=idx)
    except Exception:
        sys.exit("한글 폰트를 찾지 못했습니다. FONT 경로를 확인하세요.")

def glow_layer(color, center, radius):
    layer = Image.new("RGB", (S, S), (0, 0, 0))
    d = ImageDraw.Draw(layer)
    cx, cy = center
    d.ellipse([cx - radius, cy - radius, cx + radius, cy + radius], fill=color)
    return layer.filter(ImageFilter.GaussianBlur(radius * 0.55))

def dim(c, k):
    return tuple(int(v * k) for v in c)

def make_base(t):
    img = Image.new("RGB", (S, S), t["base"])
    d = ImageDraw.Draw(img)
    for y in range(S):  # 아래로 갈수록 살짝 어두워짐
        k = 1.0 - 0.45 * (y / S)
        d.line([(0, y), (S, y)], fill=dim(t["base"], k))
    img = ImageChops.add(img, dim_img(glow_layer(t["glowL"], (-40, 380), 330), 0.55))
    img = ImageChops.add(img, dim_img(glow_layer(t["glowR"], (S + 40, 330), 330), 0.55))
    # 글자 영역 주변 가로 빛줄기(좌 파랑, 우 주황)
    img = ImageChops.add(img, dim_img(glow_layer(t["glowL"], (60, 880), 170), 0.5))
    img = ImageChops.add(img, dim_img(glow_layer(t["glowR"], (S - 60, 860), 170), 0.5))
    return img

def dim_img(im, k):
    return im.point(lambda v: int(v * k))

def place_photo(base, photo_path, focus, photo_h, t):
    """원본을 비율 유지로 채워 위쪽에 놓는다. 원본 픽셀은 그대로(축소/확대·자르기만)."""
    ph = Image.open(photo_path).convert("RGB")
    w, h = ph.size
    scale = max(S / w, photo_h / h)
    nw, nh = int(round(w * scale)), int(round(h * scale))
    ph = ph.resize((nw, nh), Image.LANCZOS)
    fx, fy = focus
    # 초점이 사진 영역 중앙 근처(가로 중앙, 세로 40%)에 오도록 잘라낸다
    left = int(min(max(fx * nw - S * 0.5, 0), nw - S))
    top = int(min(max(fy * nh - photo_h * 0.40, 0), nh - photo_h))
    ph = ph.crop((left, top, left + S, top + photo_h))
    # 아래쪽을 배경으로 녹이는 마스크(위 55%는 불투명 100%)
    mask = Image.new("L", (S, photo_h), 255)
    md = ImageDraw.Draw(mask)
    fade0 = int(photo_h * 0.62)
    for y in range(fade0, photo_h):
        a = int(255 * (1 - (y - fade0) / (photo_h - fade0)))
        md.line([(0, y), (S, y)], fill=a)
    # 얼굴 쪽은 건드리지 않고 좌우 가장자리에만 약한 색광(림라이트 느낌)을 더한다
    rim = Image.new("RGB", (S, photo_h), (0, 0, 0))
    rd = ImageDraw.Draw(rim)
    rd.rectangle([0, 0, int(S * 0.16), photo_h], fill=dim(t["glowL"], 0.28))
    rd.rectangle([int(S * 0.84), 0, S, photo_h], fill=dim(t["glowR"], 0.28))
    rim = rim.filter(ImageFilter.GaussianBlur(70))
    ph = ImageChops.add(ph, rim)
    base.paste(ph, (0, 0), mask)
    return base

def stroke_text(draw, xy, text, f, fill, stroke):
    # 부드러운 그림자 + 굵은 외곽(블랙 느낌)
    draw.text((xy[0], xy[1] + 6), text, font=f, fill=(0, 0, 0), stroke_width=stroke + 2, stroke_fill=(0, 0, 0))
    draw.text(xy, text, font=f, fill=fill, stroke_width=stroke, stroke_fill=fill)

def fit(draw, text, size, max_w, idx=IDX_BLACK, floor=56):
    f = font(size, idx)
    while draw.textlength(text, font=f) > max_w and f.size > floor:
        f = font(f.size - 4, idx)
    return f

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--photo", required=True)
    ap.add_argument("--top", default="", help="보조 줄: '날짜 매체 보도' 형식 권장(출처 필수)")
    ap.add_argument("--title", required=True, help="제목, '|'로 줄바꿈")
    ap.add_argument("--tag", required=True, help="박스 키워드 10자 이내")
    ap.add_argument("--out", required=True)
    ap.add_argument("--theme", default="bomi", choices=THEMES)
    ap.add_argument("--brand", default=None, help="하단 워드마크(기본: 테마별 블로그명)")
    ap.add_argument("--focus", default="0.5,0.35", help="얼굴 중심(가로,세로 비율)")
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args()

    t = THEMES[a.theme]
    brand = a.brand or t["brand"]
    fx, fy = (float(v) for v in a.focus.split(","))
    lines = [x.strip() for x in a.title.split("|") if x.strip()]
    if len(lines) > 2: print("[경고] 제목은 2줄 권장입니다.", file=sys.stderr)
    for ln in lines:
        if len(ln) > 14: print(f"[경고] '{ln}' {len(ln)}자. 13자 안팎 권장.", file=sys.stderr)
    if len(a.tag) > 10: print(f"[경고] 박스 '{a.tag}' {len(a.tag)}자. 10자 이내 권장.", file=sys.stderr)
    if a.top and "보도" not in a.top and "출처" not in a.top and "보" not in a.top:
        print("[경고] 보조 줄에 출처(매체)가 보이지 않습니다. 출처를 쓰세요.", file=sys.stderr)

    photo_h = int(S * 0.62)
    img = make_base(t)
    img = place_photo(img, a.photo, (fx, fy), photo_h, t)
    d = ImageDraw.Draw(img)

    max_w = int(S * 0.84)
    y = int(S * 0.585)
    if a.top:
        ft = font(34, IDX_BOLD)
        w = d.textlength(a.top, font=ft)
        d.text(((S - w) / 2, y), a.top, font=ft, fill=(225, 232, 245))
    y = int(S * 0.628)
    # 제목 줄들은 같은 크기로 맞춘다(가장 긴 줄 기준)
    longest = max(lines, key=lambda s: d.textlength(s, font=font(104)))
    f1 = fit(d, longest, 104, max_w)
    lh = int(f1.size * 1.10)
    for ln in lines:
        w = d.textlength(ln, font=f1)
        stroke_text(d, ((S - w) / 2, y), ln, f1, (255, 255, 255), 2)
        y += lh
    y += 12
    # 주황(금) 박스
    f2 = fit(d, a.tag, 66, int(S * 0.62), floor=44)
    tw = d.textlength(a.tag, font=f2)
    bw, bh = int(tw + 70), int(f2.size * 1.42)
    x0 = (S - bw) // 2
    d.rectangle([x0, y, x0 + bw, y + bh], fill=t["accent"])
    d.text(((S - tw) / 2, y + (bh - f2.size) / 2 - 6), a.tag, font=f2, fill=t["boxtext"],
           stroke_width=1, stroke_fill=t["boxtext"])
    # 워드마크(불투명도 약 70%) + 양옆 가는 선
    ov = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    od = ImageDraw.Draw(ov)
    fb = font(34, IDX_BOLD)
    bw2 = od.textlength(brand, font=fb)
    by = int(S * 0.952)
    od.text(((S - bw2) / 2, by), brand, font=fb, fill=(255, 255, 255, 179))
    ly = by + 21
    od.line([(int(S * 0.20), ly), ((S - bw2) / 2 - 26, ly)], fill=(255, 255, 255, 110), width=2)
    od.line([((S + bw2) / 2 + 26, ly), (int(S * 0.80), ly)], fill=(255, 255, 255, 110), width=2)
    img = Image.alpha_composite(img.convert("RGBA"), ov).convert("RGB")
    img.save(a.out)
    print("저장:", a.out)

    if a.check:
        g = img.copy(); gd = ImageDraw.Draw(g)
        gd.rectangle([0, 0, S - 1, photo_h], outline=(0, 255, 0), width=3)         # 사진 영역
        gd.rectangle([int(S * .15), 0, int(S * .85), S - 1], outline=(255, 0, 0), width=2)  # 중앙 70%
        gd.line([(0, int(S * .585)), (S, int(S * .585))], fill=(255, 255, 0), width=2)  # 글자 시작선
        p = os.path.splitext(a.out)[0] + "_guide.png"
        g.save(p); print("가이드:", p)

if __name__ == "__main__":
    main()
