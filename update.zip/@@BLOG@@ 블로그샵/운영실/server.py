#!/usr/bin/env python3
"""@@BLOG@@ 운영실 — 로컬 승인 화면 서버 (표준 라이브러리만 사용, 이 컴퓨터에서만 접속).

실행:  python3 운영실/server.py   →  http://127.0.0.1:3700
하는 일: 포스팅/ 폴더의 원고·사진을 카드로 보여 주고, 승인·보류·제외·수정 메모와
발행 시간 슬롯 큐를 관리한다. 네이버에는 접속하지 않고 발행도 하지 않는다 (AU12, C13).
"""
import json, os, re, shutil, subprocess, sys, mimetypes, time, unicodedata
from datetime import datetime, timedelta, date
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs, unquote

HERE = os.path.dirname(os.path.abspath(__file__))
BASE = os.path.dirname(HERE)                       # @@BLOG@@ 블로그샵/
POSTS = os.path.join(BASE, "포스팅")
RULES = os.path.join(BASE, "자료", "글쓰기_규칙.txt")
LOG = os.path.join(BASE, "발행기록", "발행기록.md")
STATE = os.path.join(HERE, "상태.json")
PORT = int(os.environ.get("OPS_PORT", 3700))
DOWNLOADS = os.path.expanduser("~/Downloads")
BLOG_CODE, BLOG_NAME = "@@CODE@@", "@@BLOG@@"            # 발주ID 접두어 (이미지외주 규칙: @@CODE@@-20261012-01)
OUTSRC = os.path.join(os.path.dirname(BASE), "이미지외주", BLOG_NAME)   # 본사 협업 폴더 (Codex가 이 폴더를 읽고 씀)
OUT_ORDERS = os.path.join(OUTSRC, "01_발주서")
OUT_DELIV = os.path.join(OUTSRC, "03_납품")
OUT_PROJECT = "이미지 제작사 (@@BLOG@@)"     # ChatGPT/Codex 프로젝트명
IMG_EXT = (".png", ".jpg", ".jpeg", ".webp", ".gif")
DEFAULT_SLOTS = ["%02d:00" % h for h in range(9, 22, 2)]   # 09:00~21:00, 2시간 간격 7칸(7편). 설정 탭에서 변경


# ---------- 상태 ----------
def load_state():
    st = {"posts": {}, "queue": [], "slots": DEFAULT_SLOTS}
    if os.path.exists(STATE):
        try:
            with open(STATE, encoding="utf-8") as f:
                st.update(json.load(f))
        except Exception:
            pass
    return st


def save_state(st):
    tmp = STATE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(st, f, ensure_ascii=False, indent=2)
    os.replace(tmp, STATE)


# ---------- 원고 파싱 ----------
def parse_post(path, rel):
    with open(path, encoding="utf-8") as f:
        text = f.read()
    lines = text.splitlines()
    head = lines[0] if lines else ""
    m = re.match(r"\[원고\s*(\d+)\]\s*(.+)", head)
    num = m.group(1) if m else ""
    title = m.group(2).strip() if m else os.path.basename(path)
    kind = ""
    km = re.search(r"\(([^()]*)\)\s*$", title)
    if km:
        kind = km.group(1)
        title = title[: km.start()].strip()

    sec, cur, checks_lines = {}, None, []
    status_line = ""
    in_check = False
    for ln in lines[1:]:
        if ln.startswith("상태:"):
            status_line = ln[3:].strip()
            continue
        if ln.startswith("[발행 전 확인할 부분]"):
            in_check = True
            continue
        if in_check:
            checks_lines.append(ln)
            continue
        if ln.startswith("■"):
            cur = ln.lstrip("■").strip()
            sec[cur] = []
            continue
        if cur is not None:
            sec[cur].append(ln)

    def get(prefix):
        for k, v in sec.items():
            if k.startswith(prefix):
                return "\n".join(v).strip("\n")
        return ""

    titles = []
    for ln in get("제목 후보").splitlines():
        mm = re.match(r"^\s*(\d+)\.\s*(.+)$", ln)
        if mm:
            titles.append(mm.group(2).strip())
    recommend = ""
    for ln in get("제목 후보").splitlines():
        if ln.startswith("추천"):
            recommend = ln
    checks, buf = [], None
    for ln in checks_lines:
        if ln.startswith("- "):
            if buf:
                checks.append(buf)
            buf = ln[2:].strip()
        elif ln.strip() and buf is not None:
            buf += " " + ln.strip()
    if buf:
        checks.append(buf)

    folder = os.path.dirname(path)
    photo_dir = os.path.join(folder, f"원고{num}_사진")
    photos, source_note = [], ""
    if os.path.isdir(photo_dir):
        for fn in sorted(os.listdir(photo_dir)):
            fp = os.path.join(photo_dir, fn)
            if fn == "출처.txt":
                with open(fp, encoding="utf-8") as f:
                    source_note = f.read()
            elif fn.lower().endswith((".png", ".jpg", ".jpeg", ".webp", ".gif")):
                photos.append(os.path.relpath(fp, POSTS))
    return {
        "id": rel, "num": num, "title": title, "kind": kind, "status_line": status_line,
        "titles": titles, "recommend": recommend,
        "thumb_brief": get("썸네일"), "body": get("본문"), "checks": checks,
        "photos": photos, "source_note": source_note,
        "photo_dir": os.path.relpath(photo_dir, POSTS) if os.path.isdir(photo_dir) else "",
    }


def scan():
    days = []
    if not os.path.isdir(POSTS):
        return days
    for d in sorted(os.listdir(POSTS), reverse=True):
        dp = os.path.join(POSTS, d)
        if not os.path.isdir(dp) or d.startswith("_"):
            continue
        summ = ""
        sp = os.path.join(dp, "00_승인요약.md")
        if os.path.exists(sp):
            with open(sp, encoding="utf-8") as f:
                summ = f.read()
        pool = ""
        pp = os.path.join(dp, "00_후보풀.md")
        if os.path.exists(pp):
            with open(pp, encoding="utf-8") as f:
                pool = f.read()
        extras = sorted((fn for fn in os.listdir(dp) if re.match(r"00_후보풀_추가\d+\.md$", fn)),
                        key=lambda x: int(re.search(r"(\d+)\.md$", x).group(1)))
        for fn in extras:                       # /후보추가가 만든 추가 후보는 같은 후보풀 표 뒤에 붙는다 (번호는 이어서)
            with open(os.path.join(dp, fn), encoding="utf-8") as f:
                pool += "\n\n" + f.read()
        posts = []
        for fn in sorted(os.listdir(dp)):
            if re.match(r"원고\d+_.+\.txt$", fn):
                try:
                    posts.append(parse_post(os.path.join(dp, fn), f"{d}/{fn}"))
                except Exception as e:  # 원고 하나가 깨져도 화면은 뜬다
                    posts.append({"id": f"{d}/{fn}", "title": fn, "error": str(e), "titles": [],
                                  "checks": [], "photos": [], "body": "", "thumb_brief": "",
                                  "recommend": "", "kind": "", "num": "", "status_line": "",
                                  "source_note": "", "photo_dir": ""})
        days.append({"date": d, "summary": summ, "pool": pool, "posts": posts})
    return days


# ---------- 슬롯 큐 ----------
def assign_slots(queue, slots, now=None):
    """승인한 글을 순서대로 '지금 이후의 가장 가까운 빈 슬롯'에 배정한다 (TJ13)."""
    now = now or datetime.now()
    slots = sorted(set(slots))
    out, day = [], now.date()
    seq = []
    while len(seq) < len(queue):
        for s in slots:
            h, m = map(int, s.split(":"))
            dt = datetime.combine(day, datetime.min.time()).replace(hour=h, minute=m)
            if dt > now:
                seq.append(dt)
        day += timedelta(days=1)
        if len(seq) > 500:
            break
    for pid, dt in zip(queue, seq):
        out.append((pid, dt))
    return out


def parse_sched(s, now):
    """'10/13 09:00', '2026-10-13 09:00', '09:00' → datetime. 못 읽으면 None."""
    s = (s or "").strip()
    m = re.match(r"^(?:(\d{4})-(\d{1,2})-(\d{1,2})|(\d{1,2})/(\d{1,2}))?\s*(\d{1,2}):(\d{2})$", s)
    if not m:
        return None
    y = int(m.group(1)) if m.group(1) else now.year
    mo = int(m.group(2) or m.group(4) or now.month)
    d = int(m.group(3) or m.group(5) or now.day)
    try:
        return datetime(y, mo, d, int(m.group(6)), int(m.group(7)))
    except ValueError:
        return None


def weekday_ko(dt):
    return "월화수목금토일"[dt.weekday()]


# ---------- 발행기록.md 에 한 줄 추가 ----------
def append_log(row):
    if not os.path.exists(LOG):
        return False
    with open(LOG, encoding="utf-8") as f:
        lines = f.read().split("\n")
    try:
        i0 = next(i for i, l in enumerate(lines) if l.startswith("## 글별 기록"))
        ih = next(i for i in range(i0, len(lines)) if lines[i].startswith("| 발행일"))
    except StopIteration:
        return False
    cols = [c.strip() for c in lines[ih].strip().strip("|").split("|")]
    vals = [row.get(c, "") for c in cols]
    new = "| " + " | ".join(str(v).replace("|", "/") for v in vals) + " |"
    j = ih + 2
    bi = cols.index("블로그") if "블로그" in cols else -1
    while j < len(lines) and lines[j].startswith("|"):
        cells = [c.strip() for c in lines[j].strip().strip("|").split("|")]
        # 비어 있는 서식 줄(블로그 칸만 채워진 자리 표시 줄)이면 그 앞에 넣는다
        if all(c == "" for k, c in enumerate(cells) if k != bi):
            break
        j += 1
    lines.insert(j, new)
    with open(LOG, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    return True


def update_log_url(date_s, time_s, title, url):
    """이미 기록된 글의 메모 칸(URL)만 고친다. 같은 발행일·시각·제목 줄을 찾아 바꾼다."""
    if not os.path.exists(LOG):
        return False
    with open(LOG, encoding="utf-8") as f:
        lines = f.read().split("\n")
    try:
        i0 = next(i for i, l in enumerate(lines) if l.startswith("## 글별 기록"))
        ih = next(i for i in range(i0, len(lines)) if lines[i].startswith("| 발행일"))
    except StopIteration:
        return False
    cols = [c.strip() for c in lines[ih].strip().strip("|").split("|")]
    mi, ti = cols.index("메모"), cols.index("제목")
    memo = ("URL " + url) if url else "운영실에서 발행 완료 기록"
    for j in range(ih + 2, len(lines)):
        if not lines[j].startswith("|"):
            break
        cells = [c.strip() for c in lines[j].strip().strip("|").split("|")]
        if len(cells) == len(cols) and cells[0] == date_s and cells[1] == time_s and cells[ti] == title.replace("|", "/"):
            cells[mi] = memo.replace("|", "/")
            lines[j] = "| " + " | ".join(cells) + " |"
            with open(LOG, "w", encoding="utf-8") as f:
                f.write("\n".join(lines))
            return True
    return False


def append_rule(pid, memo):
    stamp = date.today().isoformat()
    with open(RULES, encoding="utf-8") as f:
        cur = f.read()
    with open(RULES, "a", encoding="utf-8") as f:
        if cur and not cur.endswith("\n"):
            f.write("\n")
        f.write(f"- [{stamp}] {pid}: {memo.strip()}\n")


def voice_path(pid):
    """원고 id('날짜/원고N_주제.txt') → 같은 폴더의 '원고N_저자말.md'"""
    d, fn = os.path.split(pid)
    m = re.match(r"(원고\d+)_", fn)
    return os.path.join(POSTS, d, (m.group(1) if m else "원고") + "_저자말.md")


def voice_marked_used(pid):
    """저자말.md 에서 Claude(/말씀녹이기)가 [x]로 표시한 번호들 → 운영실 '반영됨' 표시에 합친다."""
    try:
        with open(voice_path(pid), encoding="utf-8") as f:
            return {int(n) for n in re.findall(r"^##\s*(\d+)\.\s*\[x\]", f.read(), re.M)}
    except OSError:
        return set()


def write_voice_file(pid, items):
    """저자가 말한 내용을 Claude(/말씀녹이기)가 읽을 파일로 쓴다."""
    path = voice_path(pid)
    if not items:
        if os.path.exists(path):
            os.remove(path)
        return
    out = [f"# 저자 말하기 — {pid}", "",
           "> @@OWNER@@이 말한 내용(받아쓰기). 어투와 핵심을 살려 본문에 녹일 것 (/말씀녹이기). 아직 반영 안 된 것은 [ ].", ""]
    for i, it in enumerate(items, 1):
        mark = "[x]" if it.get("used") else "[ ]"
        out.append(f"## {i}. {mark} 대목: {it.get('section') or '(전체/자유)'}  ({it.get('at','')})")
        out.append(it.get("text", "").strip())
        out.append("")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(out))



# ---------- 외주 발주 (ChatGPT) ----------
def order_id(pid):
    """'2026-10-12/원고3_주제.txt' → '@@CODE@@-20261012-03'"""
    d, fn = os.path.split(pid)
    m = re.match(r"원고(\d+)_", fn)
    dd = d.replace("-", "")
    return f"{BLOG_CODE}-{dd}-{int(m.group(1)):02d}" if m else f"{BLOG_CODE}-{dd}-00"


def find_post(pid):
    d, fn = os.path.split(pid)
    path = os.path.join(POSTS, d, fn)
    if not os.path.isfile(path):
        return None
    return parse_post(path, pid)


def order_path(pid):
    d, fn = os.path.split(pid)
    m = re.match(r"(원고\d+)_", fn)
    return os.path.join(POSTS, d, (m.group(1) if m else "원고") + "_발주서.md")


def build_order(pid, final_title="", reorder=0):
    p = find_post(pid)
    if not p:
        return None
    oid = order_id(pid)
    title = final_title or p["title"]
    scenes = [m.strip() for m in re.findall(r"\(사진 자리[:：]?\s*([^)\n]*)\)", p["body"])]
    scenes = [x for x in scenes if not re.search(r"\.(png|jpe?g|webp)", x, re.I)]   # 자체 제작 카드 파일은 사진 주문이 아니다
    heads = [h[3:].strip() for h in p["sections"]] if p.get("sections") else \
            [l[3:].strip() for l in p["body"].splitlines() if l.startswith("## ")]
    out = [f"[발주서] {oid} · {BLOG_NAME}", "",
           f"글 제목: {title}", f"글 종류: {p['kind'] or '-'}", "",
           "이 글에 필요한 이미지는 모두 8장입니다: 썸네일 1장 + 인포그래픽 1장 + 사진 6장 (더 만들지 마세요).",
           "규칙은 AGENTS.md와 이미지외주/@@BLOG@@/스타일가이드.md를 따르세요 (규격·여백 금지·쓰기 범위 포함).",
           "납품: 만든 이미지를 이미지외주/@@BLOG@@/03_납품/ 에 복사하고 경로를 알려 주세요. 파일명은 아래 규칙.", "",
           *([f"※ 재주문 {reorder}차: 글의 관점이 바뀌어 본문·제목·썸네일 문구가 새로 확정됐습니다. 이전에 납품한 이미지는 폐기했고 재사용하지 마세요. 아래 지시서와 본문 기준으로 처음부터 새로 만드세요.", ""] if reorder else []),
           "■ A. 썸네일 (1장, 1080×1080 PNG)",
           f"파일명: {oid}_THUMB_v1",
           "아래 썸네일 지시서의 글자는 확정 문구입니다. 한 글자도 바꾸지 마세요.",
           re.sub(r"\s*파일:\s*\S+\.png\.?", "", p["thumb_brief"]).strip() or "(썸네일 지시서 없음 — 글 제목을 큰 제목으로 쓰세요)", "",
           "■ B. 인포그래픽 (세로형 1장)",
           f"파일명: {oid}_INFO_v1",
           "아래 [본문]에 있는 사실만 쓰세요. 새 수치와 사실을 추가하지 마세요. 핵심 5~7개로 요약하고, 소제목 순서를 따르세요.",
           "소제목: " + (" / ".join(heads) if heads else "(없음)"), "",
           "■ C. 사진 (총 6장 — 본문에 2장씩 나란히 3줄로 배치합니다)",
           f"파일명: {oid}_PHOTO_01 ~ 06 (01·02가 첫 줄, 03·04가 둘째 줄, 05·06이 셋째 줄)",
           "같은 줄의 두 장은 서로 짝이 되는 장면(전·후, 안·밖, 옛것·지금 등)으로 고르세요. 후보를 더 만들지 말고 6장만 고르세요.",
           "필요한 장면:"]
    out += [f"- {x}" for x in scenes] if scenes else ["- 본문 소제목 순서에 맞는 장면 6개(2장씩 3쌍)를 직접 고르세요."]
    out += ["각 사진 파일을 첨부하세요. 첨부가 안 되면 이미지가 있는 페이지 URL과 출처를 표로 주세요.", "",
            "■ [본문]", p["body"].strip(), ""]
    return oid, "\n".join(out)


IS_WIN = sys.platform == "win32"
DETACH = ({"creationflags": 0x00000008 | 0x00000200 | 0x08000000} if IS_WIN else {"start_new_session": True})


def pbcopy(text):
    """클립보드에 복사한다. Windows 는 clip(UTF-16LE+BOM), Mac 은 pbcopy."""
    try:
        if IS_WIN:
            pr = subprocess.Popen(["clip"], stdin=subprocess.PIPE)
            pr.communicate(("\ufeff" + text).encode("utf-16-le"))
            return pr.returncode == 0
        env = dict(os.environ, LC_ALL="en_US.UTF-8")
        pr = subprocess.Popen(["pbcopy"], stdin=subprocess.PIPE, env=env)
        pr.communicate(text.encode("utf-8"))
        return pr.returncode == 0
    except Exception:
        return False


def open_path(path):
    """폴더나 파일을 기본 방식으로 연다 (Windows 탐색기 / Mac Finder)."""
    try:
        if IS_WIN:
            os.startfile(path)
        elif sys.platform == "darwin":
            subprocess.Popen(["open", path])
        else:
            subprocess.Popen(["xdg-open", path])
        return True
    except Exception:
        return False


def reveal_path(path):
    """파일을 선택한 채로 그 폴더를 연다."""
    try:
        if IS_WIN:
            subprocess.Popen(["explorer", "/select,", os.path.normpath(path)])
        elif sys.platform == "darwin":
            subprocess.Popen(["open", "-R", path])
        else:
            subprocess.Popen(["xdg-open", os.path.dirname(path)])
        return True
    except Exception:
        return False


def open_chatgpt():
    """ChatGPT 를 연다. Mac 은 앱, 그 밖에는 브라우저."""
    try:
        if sys.platform == "darwin":
            return subprocess.run(["open", "-a", "ChatGPT"], capture_output=True).returncode == 0
        if IS_WIN:
            os.startfile("https://chatgpt.com/")
            return True
        subprocess.Popen(["xdg-open", "https://chatgpt.com/"])
        return True
    except Exception:
        return False


def write_order_files(pid, ps):
    """발주서를 원고 옆(기록 사본)과 이미지외주/01_발주서(정본)에 쓴다. 클립보드·ChatGPT는 건드리지 않는다."""
    built = build_order(pid, ps.get("final_title", ""), (ps.get("order") or {}).get("reorder", 0))
    if not built:
        return None
    oid, text = built
    with open(order_path(pid), "w", encoding="utf-8") as f:      # 원고 옆 기록용 사본
        f.write(text)
    os.makedirs(OUT_ORDERS, exist_ok=True)                        # Codex가 읽는 정본
    with open(os.path.join(OUT_ORDERS, f"{oid}.md"), "w", encoding="utf-8") as f:
        f.write(text)
    return oid


def auto_prepare():
    """원고가 완성돼 보이는 즉시(발주 전) 발주서를 자동으로 만들어 둔다 (@@OWNER@@ 확정 2026-10-14: 시점=원고 완성 직후).
    ChatGPT로 보내는 것(발주 버튼)은 @@OWNER@@이 한다. 보내기 전까지 원고가 바뀌면 발주서도 다시 쓴다."""
    st = load_state(); changed = False
    for d in os.listdir(POSTS) if os.path.isdir(POSTS) else []:
        dp = os.path.join(POSTS, d)
        if not os.path.isdir(dp) or d.startswith("_"):
            continue
        for fn in sorted(os.listdir(dp)):
            if not re.match(r"원고\d+_.+\.txt$", fn) or "백업" in fn:
                continue
            pid = f"{d}/{fn}"
            ps = st["posts"].setdefault(pid, {})
            if ps.get("status") in ("exclude", "published"):
                continue
            o = ps.get("order") or {}
            if o.get("status") not in (None, "none", "prepared"):
                continue
            mt = os.path.getmtime(os.path.join(dp, fn))
            if o.get("status") == "prepared" and o.get("prepared_mtime", 0) >= mt:
                continue
            try:
                oid = write_order_files(pid, ps)
            except Exception as e:
                print("auto_prepare 실패:", pid, e); continue
            if oid:
                ps["order"] = dict(o, status="prepared", id=oid, prepared_at=datetime.now().strftime("%m-%d %H:%M"), prepared_mtime=mt)
                changed = True
    if changed:
        save_state(st)


def do_order(pid):
    st = load_state()
    ps = st["posts"].setdefault(pid, {})
    oid = write_order_files(pid, ps)
    if not oid:
        return {"ok": False, "error": "원고를 찾지 못했습니다"}
    prompt = (f"이미지외주/{BLOG_NAME}/01_발주서/{oid}.md 발주서를 읽고 AGENTS.md 지침대로 진행해줘. "
              "먼저 요구사항을 3줄로 복창하고, 이어서 이미지를 만들어 03_납품에 복사한 뒤 경로를 알려줘.")
    copied = pbcopy(prompt)
    opened = open_chatgpt()
    o = ps.setdefault("order", {})
    if o.get("status") in (None, "none", "prepared"):
        o["status"] = "ordered"
    o["id"], o["at"] = oid, datetime.now().strftime("%m-%d %H:%M")
    save_state(st)
    return {"ok": True, "oid": oid, "chars": len(prompt), "copied": copied, "opened": opened,
            "project": OUT_PROJECT}


def guess_type(fn):
    u = fn.upper()
    return "thumb" if "THUMB" in u else "info" if "INFO" in u else "photo" if "PHOTO" in u else ""


def photo_sources(oid):
    """03_납품/발주ID_PHOTO_출처.txt 의 줄(파일명 / 페이지 URL / 제공처 / 이용 조건 / 등급 / 저장일)을 읽는다."""
    out = {}
    for fn in (os.listdir(OUT_DELIV) if os.path.isdir(OUT_DELIV) else []):
        if unicodedata.normalize("NFC", fn).startswith(oid) and "PHOTO" in fn.upper() and fn.lower().endswith(".txt"):
            try:
                lines = open(os.path.join(OUT_DELIV, fn), encoding="utf-8").read().splitlines()
            except Exception:
                continue
            for ln in lines:
                parts = [x.strip() for x in ln.split(" / ")]
                if len(parts) >= 5 and re.search(r"\.(jpe?g|png|webp|gif)$", parts[0], re.I):
                    out[unicodedata.normalize("NFC", parts[0])] = {
                        "url": parts[1], "provider": parts[2], "terms": parts[3], "grade": parts[4],
                        "saved": parts[5] if len(parts) > 5 else "",
                        "scene": parts[6] if len(parts) > 6 else ""}
    return out


def delivery_files(pid):
    """Codex가 03_납품/ 에 복사해 둔, 이 글(발주ID)의 이미지. 이미 가져온 것은 제외."""
    out, oid = [], order_id(pid)
    done = set(load_state()["posts"].get(pid, {}).get("order", {}).get("imported_src", []))
    srcs = photo_sources(oid)
    try:
        for fn in sorted(os.listdir(OUT_DELIV)):
            fp = os.path.join(OUT_DELIV, fn)
            if unicodedata.normalize("NFC", fn).startswith(oid) and fn.lower().endswith(IMG_EXT) and os.path.isfile(fp) and fn not in done:
                mt = os.path.getmtime(fp)
                meta = srcs.get(unicodedata.normalize("NFC", fn), {})
                out.append({"name": fn, "src": "납품", "guess": guess_type(fn), "mtime": mt,
                            "url": meta.get("url", ""), "grade": meta.get("grade", ""),
                            "kb": os.path.getsize(fp) // 1024,
                            "at": datetime.fromtimestamp(mt).strftime("%H:%M")})
    except FileNotFoundError:
        pass
    return out


def recent_downloads(pid="", hours=6):
    out, now = delivery_files(pid) if pid else [], time.time()
    try:
        for fn in os.listdir(DOWNLOADS):
            fp = os.path.join(DOWNLOADS, fn)
            if fn.lower().endswith(IMG_EXT) and os.path.isfile(fp):
                mt = os.path.getmtime(fp)
                if now - mt <= hours * 3600:
                    out.append({"name": fn, "src": "다운로드", "guess": "", "mtime": mt,
                                "kb": os.path.getsize(fp) // 1024,
                                "at": datetime.fromtimestamp(mt).strftime("%H:%M")})
    except PermissionError:
        if out:
            return {"files": out, "note": "다운로드 폴더 접근이 막혀 납품 폴더만 보여 줍니다."}
        return {"error": "다운로드 폴더 접근이 막혀 있습니다. 시스템 설정 > 개인정보 보호 및 보안 > 파일 및 폴더에서 터미널(또는 파이썬)의 '다운로드 폴더'를 허용하세요."}
    except FileNotFoundError:
        if not out:
            return {"error": "다운로드 폴더를 찾지 못했습니다"}
    out.sort(key=lambda x: (x["src"] != "납품", -x["mtime"]))      # 납품 폴더 먼저
    return {"files": out}


TYPE_NAME = {"thumb": ("00_썸네일_GPT", "ChatGPT 생성 썸네일"),
             "info": ("01_인포그래픽_GPT", "ChatGPT 생성 인포그래픽"),
             "photo": ("02_사진_", "웹 검색 사진")}


def place_file(pid, typ, ext, src_path=None, data=None, url="", keep=False, meta=None):
    """받은 이미지를 원고N_사진/ 에 규칙 이름으로 넣고 출처.txt 에 한 줄 적는다. 기존 파일은 덮어쓰지 않는다."""
    if typ not in TYPE_NAME:
        raise ValueError("종류를 고르세요")
    d, fn = os.path.split(pid)
    m = re.match(r"원고(\d+)_", fn)
    if not m:
        raise ValueError("원고 번호를 읽지 못했습니다")
    pdir = os.path.join(POSTS, d, f"원고{m.group(1)}_사진")
    os.makedirs(pdir, exist_ok=True)
    prefix, desc = TYPE_NAME[typ]
    ext = ext.lower() if ext.lower() in IMG_EXT else ".png"
    n = 1
    while os.path.exists(os.path.join(pdir, f"{prefix}{n:02d}{ext}" if typ == "photo" else f"{prefix}{n}{ext}")):
        n += 1
    name = f"{prefix}{n:02d}{ext}" if typ == "photo" else f"{prefix}{n}{ext}"
    dest = os.path.join(pdir, name)
    if src_path:
        (shutil.copy2 if keep else shutil.move)(src_path, dest)
    else:
        with open(dest, "wb") as f:
            f.write(data)
    today = date.today().isoformat()
    if typ == "photo" and meta:
        line = (f"{name} / {meta.get('url') or url or '(URL 미기록)'} / {meta.get('provider') or '웹 검색(ChatGPT)'} / "
                f"{meta.get('terms') or '이용 조건 미확인'}, @@OWNER@@ 판단·책임으로 사용 / {meta.get('grade') or '미확인'} / {today}")
    elif typ == "photo":
        line = f"{name} / {url or '(URL 미기록)'} / 웹 검색(ChatGPT) / 이용 조건 미확인, @@OWNER@@ 판단·책임으로 사용 / 미확인 / {today}"
    else:
        line = f"{name} / (ChatGPT 이미지 생성, 발주 {order_id(pid)}) / {desc} / AI 생성물 / 초록 / {today}"
    sp = os.path.join(pdir, "출처.txt")
    cur = open(sp, encoding="utf-8").read() if os.path.exists(sp) else "파일명 / 원본 URL / 제공처 / 이용 조건 / 등급 / 저장일\n"
    with open(sp, "w", encoding="utf-8") as f:
        f.write(cur + ("" if cur.endswith("\n") else "\n") + line + "\n")
    return name


def mark_delivered(pid, names):
    st = load_state()
    o = st["posts"].setdefault(pid, {}).setdefault("order", {})
    if o.get("status") in (None, "none", "ordered"):
        o["status"] = "delivered"
    o.setdefault("files", []).extend(names)
    o["delivered_at"] = datetime.now().strftime("%m-%d %H:%M")
    save_state(st)


def _latest_version(files):
    """THUMB_v1~v3 처럼 버전이 여럿이면 번호가 가장 큰 것 하나."""
    def ver(f):
        m = re.search(r"_v(\d+)", f)
        return int(m.group(1)) if m else 0
    return max(files, key=ver) if files else None


def _scene_tokens(scene):
    return [t for t in re.split(r"[·\s,/]+", scene) if t]


def _fill_photo_slots(pid, placed):
    """원고의 '(사진 자리: 설명)' 중 파일명이 없는 것을, 출처.txt의 장면 설명과 맞는 사진 파일명으로 바꾼다.
    placed = [(사진폴더 파일명, 장면 설명)]. 이미 파일명이 적힌 자리는 건드리지 않는다. 바꾸기 전 원고는 초고백업/에 둔다."""
    path = os.path.join(POSTS, pid)
    d, fn = os.path.split(pid)
    m = re.match(r"원고(\d+)_", fn)
    pdir = os.path.join(POSTS, d, f"원고{m.group(1)}_사진")
    have = os.listdir(pdir) if os.path.isdir(pdir) else []
    with open(path, encoding="utf-8") as f:
        lines = f.read().split("\n")
    free, changed, filled = list(placed), False, []
    for i, ln in enumerate(lines):
        mm = re.match(r"^(\s*)\(사진 자리\s*:\s*(.*)\)\s*$", ln)
        if not mm or any(h in mm.group(2) for h in have) or not free:
            continue
        txt = mm.group(2)
        best = max(free, key=lambda x: sum(1 for t in _scene_tokens(x[1]) if t in txt or (t[-1] in "와과의을를" and t[:-1] in txt)))
        score = sum(1 for t in _scene_tokens(best[1]) if t in txt or (t[-1] in "와과의을를" and t[:-1] in txt))
        if score <= 0:
            continue
        free.remove(best)
        lines[i] = f"{mm.group(1)}(사진 자리: {best[0]})"
        filled.append(best[0])
        changed = True
    if changed:
        bk = os.path.join(POSTS, d, "초고백업")
        os.makedirs(bk, exist_ok=True)
        dst, n = os.path.join(bk, fn), 2
        while os.path.exists(dst):
            dst = os.path.join(bk, os.path.splitext(fn)[0] + f"_{n}" + os.path.splitext(fn)[1]); n += 1
        shutil.copy2(path, dst)
        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
    return filled


def auto_import():
    """승인·발행 여부와 관계없이, 발주했거나 납품 중인 글의 03_납품 이미지를 자동으로 가져온다.
    썸네일·인포그래픽은 최신 버전 하나, 사진은 전부(검토용 모음 제외). 납품이 다 끝난 뒤(납품메모 있음 또는 2분간 변화 없음)에만 움직인다."""
    st = load_state()
    for pid, ps in list(st["posts"].items()):
        o = ps.get("order") or {}
        if o.get("status") not in ("ordered", "delivered") or not os.path.isfile(os.path.join(POSTS, pid)):
            continue
        oid = order_id(pid)
        try:
            allf = [f for f in os.listdir(OUT_DELIV) if unicodedata.normalize("NFC", f).startswith(oid)]
        except OSError:
            continue
        if not allf:
            continue
        done = any("납품메모" in unicodedata.normalize("NFC", f) for f in allf)
        newest = max(os.path.getmtime(os.path.join(OUT_DELIV, f)) for f in allf)
        if not done and time.time() - newest < 120:
            continue
        files = [f for f in delivery_files(pid) if "검토" not in f["name"] and f["guess"]]
        if not files:
            continue
        srcs = photo_sources(oid)
        items = []
        for typ in ("thumb", "info"):
            best = _latest_version([f["name"] for f in files if f["guess"] == typ])
            if best:
                items.append({"name": best, "src": "납품", "type": typ})
        items += [{"name": f["name"], "src": "납품", "type": "photo"} for f in files if f["guess"] == "photo"]
        res = do_deliver({"id": pid, "items": items})
        placed = []
        for it, moved in zip([i for i in items if i["name"] not in {e.split(":")[0] for e in res["errors"]}], res["moved"]):
            if it["type"] == "photo":
                placed.append((moved, srcs.get(unicodedata.normalize("NFC", it["name"]), {}).get("scene", "")))
        placed = [x for x in placed if x[1]]
        if placed:
            try:
                _fill_photo_slots(pid, placed)
            except Exception:
                pass


def do_deliver(body):
    pid, names, errs = body.get("id", ""), [], []
    imported = []
    srcs = photo_sources(order_id(pid)) if pid else {}
    for it in body.get("items", []):
        fn = os.path.basename(it.get("name", ""))
        from_deliv = it.get("src") == "납품"
        root = OUT_DELIV if from_deliv else DOWNLOADS
        fp = os.path.realpath(os.path.join(root, fn))
        if not fp.startswith(os.path.realpath(root) + os.sep) or not os.path.isfile(fp):
            errs.append(f"{fn}: 파일 없음")
            continue
        try:
            names.append(place_file(pid, it.get("type", ""), os.path.splitext(fn)[1], src_path=fp,
                                    url=(it.get("url") or "").strip(), keep=from_deliv,
                                    meta=srcs.get(unicodedata.normalize("NFC", fn)) if from_deliv else None))   # 납품 폴더 원본은 검수 기록으로 남긴다
            if from_deliv:
                imported.append(fn)
        except Exception as e:
            errs.append(f"{fn}: {e}")
    if names:
        mark_delivered(pid, names)
        if imported:
            st = load_state()
            o = st["posts"].setdefault(pid, {}).setdefault("order", {})
            o.setdefault("imported_src", []).extend(imported)
            save_state(st)
    return {"ok": not errs, "moved": names, "errors": errs}


# ---------- 화면용 데이터 ----------
JOBS = {}   # pid -> Popen (끝난 자식 프로세스를 거두어야 '종료'로 보인다)
CODEX = "" if IS_WIN else "/Applications/ChatGPT.app/Contents/Resources/codex-cli/bin/codex"      # ChatGPT 앱에 들어 있는 Codex CLI (키 입력 없이 직접 실행)
OUT_ROOT = os.path.dirname(OUTSRC)                                              # 이미지외주/ (AGENTS.md가 있는 곳)


def find_claude():
    """claude 실행 파일을 찾는다. PATH → 공식 설치 위치 → Claude 데스크톱 앱 안의 것 순서."""
    import glob
    from shutil import which
    if which("claude"):
        return which("claude")
    home = os.path.expanduser("~")
    if IS_WIN:
        fixed = [os.path.join(home, ".local", "bin", "claude.exe"), os.path.join(home, ".claude", "local", "claude.exe")]
        for f in fixed:
            if os.path.exists(f):
                return f
        pats = [os.path.join(os.environ.get("APPDATA", ""), "Claude", "claude-code", "*", "claude.exe"),
                os.path.join(os.environ.get("APPDATA", ""), "Claude", "claude-code", "*", "*", "claude.exe"),
                os.path.join(os.environ.get("LOCALAPPDATA", ""), "AnthropicClaude", "app-*", "resources", "claude.exe")]
        cands = [c for pat in pats for c in glob.glob(pat)]
        return max(cands, key=os.path.getmtime) if cands else None
    root = os.path.join(home, "Library", "Application Support", "Claude", "claude-code")
    cands = glob.glob(os.path.join(root, "*", "*", "claude.app", "Contents", "MacOS", "claude"))
    def ver(p):
        v = p.split(os.sep)[-5]
        return [int(x) if x.isdigit() else 0 for x in v.split(".")]
    return max(cands, key=ver) if cands else None


def pid_alive(pid):
    pr = JOBS.get(int(pid)) if str(pid).isdigit() else None
    if pr is not None:
        if pr.poll() is not None:
            JOBS.pop(int(pid), None)
            return False
        return True
    if IS_WIN:
        try:
            import ctypes
            k32 = ctypes.windll.kernel32
            h = k32.OpenProcess(0x1000, False, int(pid))
            if not h:
                return False
            code = ctypes.c_ulong()
            k32.GetExitCodeProcess(h, ctypes.byref(code))
            k32.CloseHandle(h)
            return code.value == 259
        except Exception:
            return False
    try:
        os.kill(int(pid), 0)
        return True
    except Exception:
        return False


def count_posts(day):
    dp = os.path.join(POSTS, day)
    try:
        return len([f for f in os.listdir(dp) if re.match(r"원고\d+_.+\.txt$", f) and "백업" not in f])
    except OSError:
        return 0


def start_auto_write(day, nums):
    """선택 저장 직후 백그라운드로 Claude(-p)를 띄워 /오늘글을 돌린다. 도구는 읽기·쓰기·검색·하위 에이전트만(셸 없음)."""
    exe = find_claude()
    if not exe:
        return {"status": "error", "error": "claude 실행 파일을 찾지 못했습니다 (Claude 앱 설치 확인)"}
    prompt = (f"Skill 도구로 '오늘글' 스킬을 실행해. 날짜 {day}. @@OWNER@@이 운영실에서 고른 후보는 포스팅/{day}/00_선택.md 의 번호({', '.join(str(n)+'번' for n in nums)})다. "
              "그 소재만 원고로 만든다. @@OWNER@@은 자리에 없으니 질문하지 말고 끝까지 진행해라(관점 한마디가 없으면 관점 제안으로 쓰고 상태 줄에 '관점 제안(승인 필요)' 표시). "
              "이미 포스팅/날짜/에 원고가 있는 소재는 건드리지 않고, 선택 번호 중 아직 원고가 없는 소재만 만든다. "
              "승인 요약까지 만든 뒤 멈춘다. 네이버 접속·발행·예약은 하지 않는다.")
    logp = os.path.join(HERE, f"자동작성_{day}.log")
    lf = open(logp, "a", encoding="utf-8")
    lf.write(f"\n===== {datetime.now():%Y-%m-%d %H:%M:%S} 시작 ({', '.join(map(str, nums))}번) =====\n"); lf.flush()
    pr = subprocess.Popen([exe, "-p", prompt, "--allowedTools", "Read,Write,Edit,Glob,Grep,WebFetch,WebSearch,Agent,Skill",
                           "--permission-mode", "acceptEdits"],
                          cwd=BASE, stdout=lf, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, **DETACH)
    JOBS[pr.pid] = pr
    return {"status": "running", "pid": pr.pid, "started": datetime.now().strftime("%H:%M"), "nums": nums, "log": os.path.basename(logp),
            "before_n": count_posts(day)}


def pending_req_ids(day):
    """00_추가요청.md 기준으로 아직 후보풀_추가N.md가 없는 요청 번호."""
    return [r["id"] for r in load_state().get("requests", {}).get(day, [])
            if not os.path.exists(os.path.join(POSTS, day, f"00_후보풀_추가{r['id']}.md"))]


def start_auto_extra(day):
    """요청 보내기 직후 백그라운드로 Claude(-p)를 띄워 /후보추가를 돌린다 (셸 없음)."""
    exe = find_claude()
    if not exe:
        return {"status": "error", "error": "claude 실행 파일을 찾지 못했습니다 (Claude 앱 설치 확인)"}
    ids = pending_req_ids(day)
    prompt = (f"Skill 도구로 '후보추가' 스킬을 실행해. 날짜 {day}. 포스팅/{day}/00_추가요청.md 의 [대기] 요청 전부가 일감이다. "
              "@@OWNER@@은 자리에 없으니 질문하지 말고 끝까지 진행해라. 요청마다 00_후보풀_추가N.md 를 만든다(형식·번호 이어 붙이기 규칙은 스킬대로). "
              "글은 쓰지 않는다. 네이버 접속·발행·예약은 하지 않는다.")
    logp = os.path.join(HERE, f"후보추가_{day}.log")
    lf = open(logp, "a", encoding="utf-8")
    lf.write(f"\n===== {datetime.now():%Y-%m-%d %H:%M:%S} 시작 (요청 {', '.join(map(str, ids))}) =====\n"); lf.flush()
    pr = subprocess.Popen([exe, "-p", prompt, "--allowedTools", "Read,Write,Edit,Glob,Grep,WebFetch,WebSearch,Agent,Skill",
                           "--permission-mode", "acceptEdits"],
                          cwd=BASE, stdout=lf, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, **DETACH)
    JOBS[pr.pid] = pr
    return {"status": "running", "pid": pr.pid, "started": datetime.now().strftime("%H:%M"), "ids": ids, "log": os.path.basename(logp)}


def unused_voice(pid, ps):
    """아직 본문에 녹이지 않은 저자 말 (운영실 상태 + 저자말.md 의 [x] 표시를 합쳐서 본다)."""
    marked = voice_marked_used(pid)
    return [it for i, it in enumerate(ps.get("voice", [])) if not (it.get("used") or (i + 1) in marked)]


def start_weave(st, pid, package_only=False):
    """저자 말 저장 직후 백그라운드로 Claude(-p)를 띄워 /말씀녹이기를 돌린다 (셸 없음). 이미 돌고 있으면 끝난 뒤 한 번 더."""
    ps = st["posts"].setdefault(pid, {})
    w = ps.get("weave") or {}
    if w.get("status") == "running" and pid_alive(w.get("pid")):
        w["rerun"] = True
        ps["weave"] = w
        return
    exe = find_claude()
    if not exe:
        ps["weave"] = {"status": "failed", "error": "claude 실행 파일을 찾지 못했습니다 (Claude 앱 설치 확인)"}
        return
    d, fn = os.path.split(pid)
    m = re.match(r"원고(\d+)_", fn)
    num = f"원고{m.group(1)}" if m else fn
    cur = find_post(pid)
    before = w.get("before") if w.get("status") == "failed" and w.get("before") is not None else (cur or {}).get("body", "")
    first = (f"이 원고의 저자 말은 이미 본문에 반영돼 있다. 말씀녹이기는 다시 하지 말고, 현재 본문과 상태 줄의 관점 문장을 그대로 기준으로 삼아 아래 '새 관점 패키지'만 만든다. 대상: {num} (날짜 {d}). "
             if package_only else
             f"Skill 도구로 '말씀녹이기' 스킬을 실행해. 대상: {num} (날짜 {d}). 저자말 파일은 포스팅/{d}/{num}_저자말.md 의 [ ] 항목 전부다. ")
    prompt = (first +
              "@@OWNER@@은 자리에 없으니 질문하지 말고 끝까지 진행해라. " + ("" if package_only else "초고백업 → 목소리 지도 → 글 전체 재구성 → AI 티·규칙 점검 → 저자말.md [x] 표시 순서를 지킨다. ") +
              "@@OWNER@@의 말은 그대로 살리고, 말에 없는 사실·경험·감정·인물 평가는 덧붙이지 않는다. @@BLOG@@ 말투(채널지침)를 따른다. 네이버 접속·발행·예약은 하지 않는다. "
              "【이어서 같은 원고에 '새 관점 패키지'를 만든다 — 순서대로】 "
              "(1) 새로 확정된 관점 문장(상태 줄)과 새 본문을 기준으로 채널지침/@@BLOG@@.md의 제목 공식과 홈판 제목 규칙을 적용해 원고의 '■ 제목 후보' 블록을 새 5개와 '추천: N번' 줄로 통째로 교체하고, 원고 맨 첫 줄 '[원고 N] 제목 (종류)'의 제목도 추천 제목으로 바꾼다(종류 괄호는 유지). 옛 관점의 제목은 남기지 않는다. "
              "(2) '■ 썸네일 지시서' 블록을 새 추천 제목·새 관점에 맞게 다시 쓴다. 종류는 기존 지시서를 따른다: 정보형(텍스트형)이면 '- 큰 제목: …'(12자 안팎), '- 강조 박스(…): …'(10자 이내) 줄을 유지하고, 연예 이슈형이면 '첫 사진이 대표 이미지'라는 기존 방침을 유지하며 문구만 새 제목에 맞춘다. "
              "(3) 본문의 '(사진 자리: …)' 줄과 사진 파일은 바꾸거나 빼지 않는다(사규 사진 방침 그대로). 새 본문과 어긋나 보이는 사진·캡션은 고치지 말고 '[발행 전 확인할 부분]'에 한 줄로만 알린다. "
              "(4) '[발행 전 확인할 부분]'에 제목·썸네일·사진 자리를 바꾼 내용을 한 줄씩 적는다. 형식과 파일 구조는 운영실이 읽으니 유지한다.")
    logp = os.path.join(HERE, f"말씀녹이기_{d}.log")
    lf = open(logp, "a", encoding="utf-8")
    lf.write(f"\n===== {datetime.now():%Y-%m-%d %H:%M:%S} 시작 ({pid}) =====\n"); lf.flush()
    pr = subprocess.Popen([exe, "-p", prompt, "--allowedTools", "Read,Write,Edit,Glob,Grep,WebFetch,WebSearch,Agent,Skill",
                           "--permission-mode", "acceptEdits"],
                          cwd=BASE, stdout=lf, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, **DETACH)
    JOBS[pr.pid] = pr
    ps["weave"] = {"status": "running", "pid": pr.pid, "started": datetime.now().strftime("%H:%M"),
                   "log": os.path.basename(logp), "before": before, "rerun": False,
                   "before_titles": (cur or {}).get("titles", []), "before_thumb": (cur or {}).get("thumb_brief", ""),
                   "before_final_title": ps.get("final_title", "")}


def log_tail(name, n=6):
    try:
        with open(os.path.join(HERE, name), encoding="utf-8", errors="replace") as f:
            return "\n".join(f.read().strip().splitlines()[-n:])
    except OSError:
        return ""


def make_package_thumbnail(pid, p):
    """새 썸네일 지시서(큰 제목·강조 박스)로 텍스트형 썸네일을 바로 만든다 (도구/make_thumbnail.py). 이전 것은 .이전.png 로 남긴다."""
    brief = p.get("thumb_brief", "")
    m1 = re.search(r"큰 제목[^:：\n]*[:：]\s*([^\n←]+)", brief)
    m2 = re.search(r"강조 박스[^:：\n]*[:：]\s*([^\n←]+)", brief)
    if not (m1 and m2):
        return "" if "첫 사진" in brief else "지시서에서 큰 제목·강조 박스를 읽지 못함"      # 연예 이슈형은 첫 사진이 대표 이미지
    d, fn = os.path.split(pid)
    m = re.match(r"(원고\d+)_", fn)
    pdir = os.path.join(POSTS, d, (m.group(1) if m else "원고") + "_사진")
    os.makedirs(pdir, exist_ok=True)
    out = os.path.join(pdir, "00_썸네일.png")
    if os.path.exists(out):
        shutil.copy2(out, os.path.join(pdir, "00_썸네일.이전.png"))
    r = subprocess.run([sys.executable, os.path.join(BASE, "도구", "make_thumbnail.py"), "--line1", m1.group(1).strip(),
                        "--line2", m2.group(1).strip(), "--out", out], capture_output=True, text=True, timeout=60)
    return "" if r.returncode == 0 else (r.stderr or r.stdout or "썸네일 생성 실패")[-200:]


def reset_for_reorder(ps, pid):
    """새 관점으로 글이 바뀌었으니 이미지를 처음부터 다시 주문한다. 이전 납품물은 03_납품/_이전버전/ 으로 옮기고(삭제 아님),
    주문 상태를 비워 auto_prepare → (자동 전송 켬) → ChatGPT 발주로 이어지게 한다. 발행·제외 글은 건드리지 않는다."""
    o = ps.get("order") or {}
    if ps.get("status") in ("published", "exclude") or o.get("status") in (None, "none", "prepared"):
        return False
    oid = o.get("id") or order_id(pid)
    stamp = datetime.now().strftime("%Y%m%d-%H%M")
    moved = []
    if os.path.isdir(OUT_DELIV):
        dest = os.path.join(OUT_DELIV, "_이전버전", stamp)
        for fn in sorted(os.listdir(OUT_DELIV)):
            fp = os.path.join(OUT_DELIV, fn)
            if os.path.isfile(fp) and unicodedata.normalize("NFC", fn).startswith(oid):
                os.makedirs(dest, exist_ok=True)
                shutil.move(fp, os.path.join(dest, fn)); moved.append(fn)
    # 원고 사진 폴더의 옛 '생성 이미지(썸네일·인포그래픽)'만 보관 폴더로 옮기고 본문의 옛 '(사진 자리: 파일)' 줄을 지운다. 사진(스틸컷 포함)은 유지한다.
    # (옛 파일이 남아 있으면 새 납품이 들어올 때 운영실이 옛 파일을 본문에 다시 끼워 넣는다.)
    try:
        d, fn = os.path.split(pid)
        mm = re.match(r"(원고\d+)_", fn)
        pdir = os.path.join(POSTS, d, (mm.group(1) if mm else "원고") + "_사진")
        archived = []
        if os.path.isdir(pdir):
            adir = os.path.join(POSTS, d, os.path.basename(pdir) + "_이전", stamp)
            for f in sorted(os.listdir(pdir)):
                fp = os.path.join(pdir, f)
                if os.path.isfile(fp) and f.lower().endswith(IMG_EXT) and re.match(r"(00_썸네일|01_인포그래픽)", f):
                    os.makedirs(adir, exist_ok=True)
                    shutil.move(fp, os.path.join(adir, f)); archived.append(f)
        if archived:
            mp = os.path.join(POSTS, pid)
            text = open(mp, encoding="utf-8").read()
            for f in archived:
                text = re.sub(r"^\(사진 자리[:：]?\s*" + re.escape(f) + r"\)[ \t]*\n?", "", text, flags=re.M)
            open(mp, "w", encoding="utf-8").write(text)
            sp = os.path.join(pdir, "출처.txt")
            if os.path.isfile(sp):
                keep = [ln for ln in open(sp, encoding="utf-8").read().splitlines() if not any(ln.startswith(f) for f in archived)]
                open(sp, "w", encoding="utf-8").write("\n".join(keep) + ("\n" if keep else ""))
    except Exception as e:
        print("재주문 이미지 보관 실패:", e)
    ps["order"] = {"status": "none", "id": oid, "reorder": int(o.get("reorder", 0)) + 1,
                   "reorder_at": datetime.now().strftime("%m-%d %H:%M"), "prev_moved": moved}
    return True


def finish_package(st, pid):
    """말씀녹이기가 끝난 직후: 추천 제목 채택 → 썸네일 즉시 제작 → 이미지 재주문 준비(자동 전송은 설정에 따름)."""
    ps = st["posts"].setdefault(pid, {})
    w = ps.get("weave") or {}
    pk = {}
    p = find_post(pid)
    if not p:
        w["package"] = {"error": "원고를 읽지 못함"}; return
    rec = re.search(r"(\d+)\s*번", p.get("recommend", ""))
    if rec and 1 <= int(rec.group(1)) <= len(p["titles"]):
        ps["final_title"] = p["titles"][int(rec.group(1)) - 1]
        pk["title"] = ps["final_title"]
    elif ps.get("final_title") not in p["titles"]:
        ps.pop("final_title", None)
    try:
        err = make_package_thumbnail(pid, p)
        pk["thumb"] = "ok" if not err else err
    except Exception as e:
        pk["thumb"] = f"썸네일 오류: {e}"
    try:
        pk["reorder"] = reset_for_reorder(ps, pid)
    except Exception as e:
        pk["reorder"] = False; pk["reorder_error"] = str(e)
    st["auto_send"] = True       # 원 운영자 결정(2026-10-14): 이미지 재주문까지 전부 자동
    w["package"] = pk


def refresh_weaves(st):
    """돌던 말씀녹이기가 끝났으면: 저자 말이 다 반영됐으면 '완료', 아니면 '실패'(로그인 문제면 그렇게 알린다)."""
    ch = False
    for pid, ps in list(st["posts"].items()):
        w = ps.get("weave")
        if not w or w.get("status") != "running" or pid_alive(w.get("pid")):
            continue
        ch = True
        w["ended"] = datetime.now().strftime("%H:%M")
        if not unused_voice(pid, ps):
            w["status"] = "done"
            try:
                finish_package(st, pid)
            except Exception as e:
                w["package"] = {"error": str(e)}
        else:
            tail = log_tail(w.get("log", ""))
            w["status"] = "failed"
            w["error"] = ("서버가 띄운 Claude가 로그인되어 있지 않습니다. Claude 앱에 로그인한 뒤 '다시 시도'를 누르거나, '요청 복사'를 Claude 대화창에 붙여 넣으세요."
                          if "Not logged in" in tail else "저자 말이 본문에 반영되지 않은 채 끝났습니다. 로그: 운영실/" + w.get("log", ""))
        if w.get("rerun") and unused_voice(pid, ps):
            start_weave(st, pid)
    if ch:
        save_state(st)


def refresh_jobs(st):
    """돌아가던 자동 작성이 끝났으면 결과를 판정한다: 원고가 새로 생겼으면 '완료', 아니면 '실패'(로그인 문제면 그렇게 알림).
    작성 중에 선택이 바뀌었으면(rerun) 끝난 뒤 한 번 더 돌린다."""
    refresh_weaves(st)
    refresh_codex(st)
    ch = False
    for d, pk in st.get("picks", {}).items():
        j = pk.get("job")
        if j and j.get("status") == "running" and not pid_alive(j.get("pid")):
            ch = True
            j["ended"] = datetime.now().strftime("%H:%M")
            tail = log_tail(j.get("log", ""), 8)
            made = count_posts(d) - int(j.get("before_n", 0))
            if "Not logged in" in tail:
                j["status"], j["error"] = "failed", "서버가 띄운 Claude가 로그인되어 있지 않습니다. Claude 앱에 로그인한 뒤 '다시 시도'를 누르세요."
            elif made <= 0 and not re.search(r"이미|건드리지|만들지 않", tail):
                j["status"], j["error"] = "failed", "작성이 끝났지만 새 원고가 없습니다. 로그: 운영실/" + j.get("log", "")
            else:
                j["status"], j["made"] = "done", max(made, 0)      # 0편 = 선택한 소재의 원고가 이미 있어 새로 만들 것이 없었다
            if pk.get("rerun") and pk.get("nums"):
                pk["rerun"] = False
                pk["job"] = start_auto_write(d, pk["nums"])
    for d, rj in st.get("reqjobs", {}).items():
        if rj.get("status") == "running" and not pid_alive(rj.get("pid")):
            ch = True
            rj["ended"] = datetime.now().strftime("%H:%M")
            tail = log_tail(rj.get("log", ""), 8)
            left = pending_req_ids(d)
            if "Not logged in" in tail:
                rj["status"], rj["error"] = "failed", "서버가 띄운 Claude가 로그인되어 있지 않습니다. Claude 앱에 로그인한 뒤 '다시 시도'를 누르세요."
            elif set(left) & set(rj.get("ids", [])):
                rj["status"], rj["error"] = "failed", "후보 찾기가 끝났지만 추가 후보 파일이 없습니다. 로그: 운영실/" + rj.get("log", "")
            else:
                rj["status"] = "done"
            if rj.get("rerun") and left:             # 작성 중에 새 요청이 들어왔으면 한 번 더
                st["reqjobs"][d] = start_auto_extra(d)
    if ch:
        save_state(st)


def out_snapshot():
    """이미지외주/ 안에서 03_납품 밖 파일의 수정 시각 목록 (Codex가 허용 범위 밖을 건드렸는지 비교용)."""
    snap = {}
    for dp, dn, fns in os.walk(OUT_ROOT):
        rel = os.path.relpath(dp, OUT_ROOT)
        if "03_납품" in rel.split(os.sep):
            dn[:] = []
            continue
        for fn in fns:
            fp = os.path.join(dp, fn)
            try:
                snap[os.path.join(rel, fn)] = os.path.getmtime(fp)
            except OSError:
                pass
    return snap


def start_order_codex(st, pid):
    """발주서를 ChatGPT 화면에 타이핑하지 않고, Codex CLI(codex exec)에 직접 넘겨 이미지 제작사 역할로 실행한다 (원 운영자 허용 2026-10-14).
    쓰기 범위는 이미지외주/ 폴더, 네트워크는 사진 검색·생성용으로 허용. 끝났는지는 프로세스와 03_납품 도착으로 확인하고,
    03_납품 밖에서 바뀐 파일이 있으면 경고한다."""
    ps = st["posts"].setdefault(pid, {})
    o = ps.setdefault("order", {})
    oid = o.get("id") or order_id(pid)
    exe = CODEX if (CODEX and os.path.exists(CODEX)) else None
    if not exe:
        o["auto_error"] = "이 컴퓨터에서는 이미지 자동 주문을 쓸 수 없습니다. 발주서를 복사해 ChatGPT 에 붙여 넣어 주세요"
        return False
    prompt = (f"{BLOG_NAME}/01_발주서/{oid}.md 발주서를 읽고 AGENTS.md 지침대로 진행해줘. "
              "@@OWNER@@은 자리에 없으니 질문하지 말고 끝까지 진행해라(빠진 정보는 발주서와 스타일가이드 기준으로 정한다). "
              "쓰기는 03_납품/ 에만 한다. 요구사항을 3줄로 복창하고, 이미지를 만들어 03_납품에 복사한 뒤 경로를 알려줘.")
    logp = os.path.join(HERE, f"이미지주문_{oid}.log")
    lastp = os.path.join(HERE, f"이미지주문_{oid}_마지막응답.txt")
    snapp = os.path.join(HERE, f"이미지주문_{oid}_전.json")
    with open(snapp, "w", encoding="utf-8") as f:
        json.dump(out_snapshot(), f, ensure_ascii=False)
    lf = open(logp, "a", encoding="utf-8")
    lf.write(f"\n===== {datetime.now():%Y-%m-%d %H:%M:%S} 시작 ({oid}) =====\n"); lf.flush()
    pr = subprocess.Popen([exe, "exec", "-C", OUT_ROOT, "-s", "workspace-write",
                           "-c", "sandbox_workspace_write.network_access=true", "--skip-git-repo-check",
                           "-o", lastp, prompt],
                          cwd=OUT_ROOT, stdout=lf, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, **DETACH)
    JOBS[pr.pid] = pr
    o["status"], o["at"], o["auto_sent"] = "ordered", datetime.now().strftime("%m-%d %H:%M"), True
    o["codex"] = {"status": "running", "pid": pr.pid, "started": datetime.now().strftime("%H:%M"),
                  "log": os.path.basename(logp), "last": os.path.basename(lastp), "snap": os.path.basename(snapp)}
    o.pop("auto_error", None)
    return True


def refresh_codex(st):
    """돌던 Codex 주문이 끝났으면 결과를 표시한다: 03_납품에 이 주문의 파일이 있으면 '완료', 없으면 '실패'.
    03_납품 밖에서 바뀐 파일은 outside 로 알린다."""
    ch = False
    for pid, ps in st["posts"].items():
        c = (ps.get("order") or {}).get("codex")
        if not c or c.get("status") != "running" or pid_alive(c.get("pid")):
            continue
        ch = True
        c["ended"] = datetime.now().strftime("%H:%M")
        oid = (ps["order"].get("id") or order_id(pid))
        got = [f for f in (os.listdir(OUT_DELIV) if os.path.isdir(OUT_DELIV) else [])
               if unicodedata.normalize("NFC", f).startswith(oid) and f.lower().endswith(IMG_EXT)]
        try:
            with open(os.path.join(HERE, c.get("snap", "")), encoding="utf-8") as f:
                before = json.load(f)
            now = out_snapshot()
            c["outside"] = sorted(k for k in now if k not in before or abs(now[k] - before[k]) > 0.5)[:20]
        except Exception:
            c["outside"] = []
        if got:
            c["status"], c["n"] = "done", len(got)
        else:
            c["status"] = "failed"
            c["error"] = "Codex가 끝났지만 03_납품에 새 이미지가 없습니다. 로그: 운영실/" + c.get("log", "")
    if ch:
        save_state(st)


def auto_send_orders():
    """설정에서 '발주 자동 전송'을 켠 경우, 발주서가 준비된 글을 ChatGPT로 한 번만 보낸다. 실패해도 다시 시도하지 않고(중복 전송 방지)
    카드에 실패를 표시한다. 이미 발주됐거나 납품된 글은 건드리지 않는다."""
    st = load_state()
    if not st.get("auto_send"):
        return
    for pid, ps in st["posts"].items():
        o = ps.get("order") or {}
        if o.get("status") != "prepared" or o.get("auto_tried") or ps.get("status") in ("exclude", "published"):
            continue
        if not os.path.isfile(os.path.join(POSTS, pid)):
            continue
        cur = find_post(pid)
        if cur and "승인 필요" in cur.get("status_line", ""):
            continue                                   # 관점이 '제안(승인 필요)'이면 저자 말(관점 확정) 전에는 이미지를 주문하지 않는다
        o["auto_tried"] = datetime.now().strftime("%m-%d %H:%M")
        save_state(st)                                 # 먼저 기록해 두 번 보내지 않게 한다
        st = load_state()
        try:
            start_order_codex(st, pid)                 # 키 입력 대신 Codex CLI 직접 실행 (2026-10-14 원 운영자 결정 B)
        except Exception as e:
            st["posts"][pid].setdefault("order", {})["auto_error"] = str(e)[:200]
        save_state(st)
        return                                         # 한 번에 한 글만


def build_view():
    try:
        auto_prepare()         # 원고 완성 직후 발주서 자동 준비 (보내기는 @@OWNER@@)
    except Exception as e:
        print("auto_prepare 실패:", e)
    try:
        auto_send_orders()     # (설정에서 켠 경우) 준비된 발주서를 Codex로 자동 실행
    except Exception as e:
        print("auto_send_orders 실패:", e)
    try:
        auto_import()          # 납품이 끝난 글은 알아서 가져오고 사진 자리까지 채운다
    except Exception as e:
        print("auto_import 실패:", e)
    st = load_state(); refresh_jobs(st)
    days = scan()
    known = {p["id"] for d in days for p in d["posts"]}
    st["queue"] = [q for q in st["queue"] if q in known and st["posts"].get(q, {}).get("status") == "approved"]
    slot_map = {pid: dt for pid, dt in assign_slots(st["queue"], st["slots"])}
    for d in days:
        d["reqs"] = [dict(r, done=os.path.exists(os.path.join(POSTS, d["date"], f"00_후보풀_추가{r['id']}.md")))
                     for r in st.get("requests", {}).get(d["date"], [])]
    for d in days:
        for p in d["posts"]:
            s = st["posts"].get(p["id"], {})
            p["state"] = {
                "status": s.get("status", "pending"),
                "final_title": s.get("final_title", ""),
                "final_body": s.get("final_body"),        # 발행 준비 화면에서 고친 본문 (없으면 원고 그대로)
                "final_body_at": s.get("final_body_at", 0),
                "memo": s.get("memo", ""),
                "checked": s.get("checked", []),
                "published": s.get("published"),
                "voice": [dict(it, used=bool(it.get("used")) or (i + 1) in voice_marked_used(p["id"]))
                          for i, it in enumerate(s.get("voice", []))],
                "weave": s.get("weave"),                  # 저장 직후 자동 실행되는 /말씀녹이기 상태 (before = 녹이기 전 본문)
            }
            try:
                p["file_mtime"] = os.path.getmtime(os.path.join(POSTS, p["id"]))   # 원고 파일이 수정본 저장 뒤에 바뀌었는지 비교용
            except OSError:
                p["file_mtime"] = 0
            p["order"] = s.get("order", {"status": "none"})
            p["order_id"] = order_id(p["id"])
            p["order_file"] = os.path.exists(order_path(p["id"]))
            p["sections"] = [l.strip() for l in p["body"].splitlines() if l.startswith("## ")]
            dt = slot_map.get(p["id"])
            p["slot"] = f"{dt.month}/{dt.day}({weekday_ko(dt)}) {dt.strftime('%H:%M')}" if dt else ""
    return {"days": days, "queue": st["queue"], "slots": st["slots"], "picks": st.get("picks", {}), "reqjobs": st.get("reqjobs", {}),
            "today": date.today().isoformat(), "now": datetime.now().strftime("%H:%M"), "auto_send": bool(st.get("auto_send"))}


def save_picks(st, body):
    """후보풀에서 @@OWNER@@이 고른 번호(와 관점 한마디)를 상태.json과 포스팅/날짜/00_선택.md에 남긴다. Claude는 이 파일을 읽고 원고를 만든다."""
    day = str(body.get("date", ""))
    if not re.match(r"^\d{4}-\d{2}-\d{2}$", day) or not os.path.isdir(os.path.join(POSTS, day)):
        return {"ok": False, "error": "날짜 폴더를 찾지 못했습니다"}
    nums = sorted({int(n) for n in body.get("nums", []) if str(n).isdigit()})
    notes = {str(k): str(v).strip() for k, v in (body.get("notes") or {}).items() if str(v).strip() and str(k).isdigit() and int(k) in nums}
    at = datetime.now().strftime("%Y-%m-%d %H:%M")
    old = st.get("picks", {}).get(day, {}).get("job")
    st.setdefault("picks", {})[day] = {"nums": nums, "notes": notes, "at": at}
    if old and old.get("status") == "running" and pid_alive(old.get("pid")):
        st["picks"][day]["job"] = old          # 이미 작성 중이면 겹쳐 띄우지 않는다
        # 끝난 뒤 새 선택으로 한 번 더 자동 작성 — 선택(번호·관점 한마디)이 실제로 바뀐 경우에만
        st["picks"][day]["rerun"] = bool(nums) and nums != old.get("nums")
    lines = [f"# {day} @@OWNER@@이 고른 후보 (운영실 선택 저장 {at})", "",
             "`00_후보풀.md`의 번호입니다. /오늘글은 이 번호의 소재만 원고로 만듭니다.", ""]
    lines += [f"- {n}번" + (f" — 관점 한마디: {notes[str(n)]}" if str(n) in notes else "") for n in nums] or ["- (선택 없음)"]
    with open(os.path.join(POSTS, day, "00_선택.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    if nums and not st["picks"][day].get("job"):
        st["picks"][day]["job"] = start_auto_write(day, nums)
    save_state(st)
    return {"ok": True, "job": st["picks"][day].get("job")}


def save_request(st, body, act):
    """후보풀 밑 명령창: @@OWNER@@이 적은 '이런 것을 찾아줘'를 저장하고 포스팅/날짜/00_추가요청.md에 목록으로 남긴다. Claude가 /후보추가로 읽어 추가 후보를 만든다."""
    day = str(body.get("date", ""))
    if not re.match(r"^\d{4}-\d{2}-\d{2}$", day) or not os.path.isdir(os.path.join(POSTS, day)):
        return {"ok": False, "error": "날짜 폴더를 찾지 못했습니다"}
    reqs = st.setdefault("requests", {}).setdefault(day, [])
    if act == "req_add":
        text = str(body.get("text", "")).strip()
        if not text:
            return {"ok": False, "error": "찾을 내용을 적어 주세요"}
        nid = max([r["id"] for r in reqs] + [0]) + 1
        reqs.append({"id": nid, "text": text, "at": datetime.now().strftime("%m-%d %H:%M")})
    else:
        rid = int(body.get("id", 0) or 0)
        if os.path.exists(os.path.join(POSTS, day, f"00_후보풀_추가{rid}.md")):
            return {"ok": False, "error": "이미 후보가 만들어진 요청은 지울 수 없습니다"}
        st["requests"][day] = reqs = [r for r in reqs if r["id"] != rid]
    lines = [f"# {day} 추가 후보 요청 (운영실 명령창)", "",
             "@@OWNER@@이 후보풀이 마음에 들지 않아 더 찾아 달라고 적은 것입니다. `/후보추가`가 읽고 `00_후보풀_추가N.md`를 만듭니다.", ""]
    for r in reqs:
        done = os.path.exists(os.path.join(POSTS, day, f"00_후보풀_추가{r['id']}.md"))
        lines.append(f"- 요청 {r['id']} [{'완료' if done else '대기'}] ({r['at']}): {r['text']}")
    with open(os.path.join(POSTS, day, "00_추가요청.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    if act == "req_add":
        rj = st.setdefault("reqjobs", {}).get(day) or {}
        if rj.get("status") == "running" and pid_alive(rj.get("pid")):
            rj["rerun"] = True                        # 이미 찾는 중이면 끝난 뒤 새 요청까지 한 번 더
        else:
            st["reqjobs"][day] = start_auto_extra(day)
    save_state(st)
    return {"ok": True}


def delete_post(st, pid):
    """삭제: 원고 파일을 포스팅/_삭제됨/날짜/ 로 옮긴다(완전 삭제 아님, 되살리려면 파일을 되돌리면 된다)."""
    m = re.match(r"^(\d{4}-\d{2}-\d{2})/(원고\d+_.+\.txt)$", pid)
    src = os.path.join(POSTS, *pid.split("/"))
    if not m or not os.path.isfile(src):
        return {"ok": False, "error": "원고 파일을 찾지 못했습니다"}
    if st["posts"].get(pid, {}).get("status") in ("approved", "published"):
        return {"ok": False, "error": "승인·발행된 글은 먼저 승인 취소를 하세요"}
    dst_dir = os.path.join(POSTS, "_삭제됨", m.group(1))
    os.makedirs(dst_dir, exist_ok=True)
    dst = os.path.join(dst_dir, m.group(2))
    if os.path.exists(dst):
        dst = os.path.join(dst_dir, datetime.now().strftime("%H%M%S_") + m.group(2))
    shutil.move(src, dst)
    st["posts"].pop(pid, None)
    st["queue"] = [q for q in st["queue"] if q != pid]
    save_state(st)
    return {"ok": True}


def do_action(body):
    st = load_state()
    pid, act = body.get("id", ""), body.get("action", "")
    if act == "pick_save":
        return save_picks(st, body)
    if act in ("req_add", "req_del"):
        return save_request(st, body, act)
    if act == "req_retry":
        day = str(body.get("date", "")); rj = st.get("reqjobs", {}).get(day) or {}
        if pending_req_ids(day) and not (rj.get("status") == "running" and pid_alive(rj.get("pid"))):
            st.setdefault("reqjobs", {})[day] = start_auto_extra(day)
            save_state(st)
        return {"ok": True}
    if act == "pick_retry":
        day = str(body.get("date", "")); pk = st.get("picks", {}).get(day) or {}
        j = pk.get("job") or {}
        if pk.get("nums") and not (j.get("status") == "running" and pid_alive(j.get("pid"))):
            pk["job"] = start_auto_write(day, pk["nums"])
            save_state(st)
        return {"ok": True, "job": pk.get("job")}
    if act == "delete":
        return delete_post(st, pid)
    ps = st["posts"].setdefault(pid, {})
    q = st["queue"]
    if act == "approve":
        if (ps.get("weave") or {}).get("status") == "running":
            return {"ok": False, "error": "저자 말을 본문에 녹이는 중입니다. 끝난 뒤 수정 본문을 확인하고 승인하세요."}
        un = unused_voice(pid, ps)
        if un:
            return {"ok": False, "error": f"본문에 녹이지 않은 저자 말이 {len(un)}건 있습니다. 카드의 '다시 시도'로 말씀녹이기를 끝낸 뒤 승인하세요."}
        ps["status"] = "approved"
        if body.get("final_title"):
            ps["final_title"] = body["final_title"]
        if pid not in q:
            q.append(pid)                      # 승인하면 맨 뒤에 붙는다 (TJ13)
    elif act in ("hold", "exclude", "restore"):
        ps["status"] = {"hold": "hold", "exclude": "exclude", "restore": "pending"}[act]
        if pid in q:
            q.remove(pid)
        if body.get("memo"):
            ps["memo"] = body["memo"]
    elif act == "revise":
        ps["status"] = "revise"
        ps["memo"] = body.get("memo", "")
        if pid in q:
            q.remove(pid)
        if ps["memo"].strip():
            append_rule(pid, ps["memo"])       # 수정 이유는 규칙으로 쌓인다 (TJ09, DG27)
    elif act in ("up", "down", "front"):
        if pid in q:
            i = q.index(pid)
            if act == "front":
                q.insert(0, q.pop(i))
            elif act == "up" and i > 0:
                q[i - 1], q[i] = q[i], q[i - 1]
            elif act == "down" and i < len(q) - 1:
                q[i + 1], q[i] = q[i], q[i + 1]
    elif act == "check":
        ps["checked"] = body.get("checked", [])
    elif act == "final_title":
        ps["final_title"] = body.get("final_title", "")
    elif act == "final_body":
        if body.get("reset"):
            ps.pop("final_body", None)          # 원고 원본으로 되돌리기
        else:
            ps["final_body"] = body.get("final_body", "")
            ps["final_body_at"] = time.time()
    elif act == "published":
        now = datetime.now()
        # 발행시각 = 네이버 예약(발행) 시각. @@OWNER@@이 입력한 값 → 없으면 배정된 슬롯 → 없으면 지금
        slot_dt = dict(assign_slots(q, st["slots"])).get(pid)
        pub_dt = parse_sched(body.get("sched", ""), now) or slot_dt or now
        ps["status"] = "published"
        ps["published"] = {"date": pub_dt.date().isoformat(), "time": pub_dt.strftime("%H:%M"),
                           "url": body.get("url", ""), "recorded": now.strftime("%Y-%m-%d %H:%M")}
        if pid in q:
            q.remove(pid)
        view = build_view()
        title = ps.get("final_title") or next(
            (p["title"] for d in view["days"] for p in d["posts"] if p["id"] == pid), pid)
        append_log({"발행일": pub_dt.date().isoformat(), "발행시각": pub_dt.strftime("%H:%M"),
                    "블로그": "@@BLOG@@", "제목": title, "AI 파이프라인(수동/Phase1/Phase2)": "Phase1",
                    "메모": (("URL " + body["url"]) if body.get("url") else "운영실에서 발행 완료 기록")
                            + f" (예약시각 기준, 기록 {now.strftime('%m-%d %H:%M')})"})
    elif act == "set_url":
        pub = ps.get("published")
        if ps.get("status") == "published" and pub is not None:
            url = (body.get("url") or "").strip()
            if url and not re.match(r"^https?://", url):
                return {"ok": False, "error": "주소는 http:// 또는 https:// 로 시작해야 합니다"}
            pub["url"] = url
            view = build_view()
            title = ps.get("final_title") or next(
                (p["title"] for d in view["days"] for p in d["posts"] if p["id"] == pid), pid)
            update_log_url(pub.get("date", ""), pub.get("time", ""), title, url)
    elif act in ("voice_add", "voice_edit", "voice_del", "voice_used"):
        vs = ps.setdefault("voice", [])
        if act == "voice_add" and body.get("text", "").strip():
            vs.append({"id": datetime.now().strftime("%Y%m%d%H%M%S%f"), "section": body.get("section", ""),
                       "text": body["text"].strip(), "at": datetime.now().strftime("%m-%d %H:%M"), "used": False})
        else:
            for it in vs:
                if it["id"] == body.get("vid"):
                    if act == "voice_edit":
                        it["text"] = body.get("text", it["text"]).strip()
                        it["section"] = body.get("section", it["section"])
                    elif act == "voice_used":
                        it["used"] = bool(body.get("used", True))
            if act == "voice_del":
                ps["voice"] = vs = [it for it in vs if it["id"] != body.get("vid")]
        write_voice_file(pid, vs)
        if act == "voice_add" and body.get("text", "").strip():
            start_weave(st, pid)                  # 저장 = 말씀녹이기 자동 시작
    elif act == "weave_retry":
        if (ps.get("weave") or {}).get("status") != "running":
            ps.pop("weave", None)
            if unused_voice(pid, ps):
                start_weave(st, pid)
    elif act == "package_only":
        if (ps.get("weave") or {}).get("status") != "running":
            ps.pop("weave", None)
            start_weave(st, pid, package_only=True)
    elif act == "weave_dismiss":
        if (ps.get("weave") or {}).get("status") in ("done", "failed"):
            ps.pop("weave", None)
    elif act == "auto_send":
        st["auto_send"] = bool(body.get("on"))
    elif act in ("order_done", "order_reset"):
        o = ps.setdefault("order", {})
        o["status"] = "done" if act == "order_done" else "ordered"
    elif act == "slots":
        slots = [s for s in body.get("slots", []) if re.match(r"^\d{2}:\d{2}$", s)]
        if slots:
            st["slots"] = sorted(set(slots))
    save_state(st)
    return {"ok": True}


# ---------- HTTP ----------
class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, data, ctype="application/json; charset=utf-8"):
        if isinstance(data, (dict, list)):
            data = json.dumps(data, ensure_ascii=False).encode("utf-8")
        elif isinstance(data, str):
            data = data.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _local_only(self):
        host = (self.headers.get("Host") or "").split(":")[0]
        return host in ("127.0.0.1", "localhost")

    def do_GET(self):
        if not self._local_only():
            return self._send(403, {"error": "local only"})
        u = urlparse(self.path)
        if u.path in ("/", "/index.html"):
            with open(os.path.join(HERE, "index.html"), "rb") as f:
                return self._send(200, f.read(), "text/html; charset=utf-8")
        if u.path == "/api/state":
            return self._send(200, build_view())
        if u.path == "/api/rules":
            with open(RULES, encoding="utf-8") as f:
                return self._send(200, {"text": f.read()})
        if u.path == "/api/downloads":
            return self._send(200, recent_downloads(unquote(parse_qs(u.query).get("id", [""])[0])))
        if u.path == "/dl":
            q = parse_qs(u.query)
            fn = os.path.basename(unquote(q.get("n", [""])[0]))
            root = OUT_DELIV if q.get("s", [""])[0] == "납품" else DOWNLOADS
            fp = os.path.realpath(os.path.join(root, fn))
            if not fp.startswith(os.path.realpath(root) + os.sep) or not os.path.isfile(fp) \
                    or not fn.lower().endswith(IMG_EXT):
                return self._send(404, {"error": "not found"})
            with open(fp, "rb") as f:
                return self._send(200, f.read(), mimetypes.guess_type(fp)[0] or "application/octet-stream")
        if u.path == "/file":
            rel = unquote(parse_qs(u.query).get("p", [""])[0])
            full = os.path.realpath(os.path.join(POSTS, rel))
            if not full.startswith(os.path.realpath(POSTS) + os.sep) or not os.path.isfile(full):
                return self._send(404, {"error": "not found"})
            ctype = mimetypes.guess_type(full)[0] or "application/octet-stream"
            with open(full, "rb") as f:
                return self._send(200, f.read(), ctype)
        self._send(404, {"error": "not found"})

    def do_POST(self):
        if not self._local_only():
            return self._send(403, {"error": "local only"})
        n = int(self.headers.get("Content-Length") or 0)
        u = urlparse(self.path)
        if u.path == "/api/upload":                       # 파일을 끌어다 놓거나 직접 고른 경우 (원본 바이트)
            q = parse_qs(u.query)
            if n > 40 * 1024 * 1024:
                return self._send(200, {"ok": False, "error": "40MB를 넘는 파일입니다"})
            data = self.rfile.read(n)
            try:
                pid = q.get("id", [""])[0]
                name = place_file(pid, q.get("type", [""])[0], os.path.splitext(q.get("name", [""])[0])[1],
                                  data=data, url=q.get("url", [""])[0])
                mark_delivered(pid, [name])
                return self._send(200, {"ok": True, "moved": [name]})
            except Exception as e:
                return self._send(200, {"ok": False, "error": str(e)})
        body = json.loads(self.rfile.read(n) or b"{}")
        if u.path == "/api/action":
            return self._send(200, do_action(body))
        if u.path == "/api/order":
            return self._send(200, do_order(body.get("id", "")))
        if u.path == "/api/deliver":
            return self._send(200, do_deliver(body))
        if u.path == "/api/photodir":                 # 이미지 발주: 사진 저장 폴더를 (없으면 만들어) Finder로 연다
            post = find_post(body.get("id", ""))
            if not post:
                return self._send(404, {"ok": False, "error": "no post"})
            d_, fn_ = os.path.split(body["id"])
            m_ = re.match(r"(원고\d+)_", fn_)
            if not m_:
                return self._send(404, {"ok": False, "error": "no num"})
            full = os.path.join(POSTS, d_, f"{m_.group(1)}_사진")
            os.makedirs(full, exist_ok=True)
            open_path(full)
            return self._send(200, {"ok": True, "dir": os.path.relpath(full, POSTS)})
        if u.path == "/api/open":
            if body.get("file"):                      # 이미지 파일을 선택한 채로 그 폴더를 Finder에 보여 준다
                fp = os.path.realpath(os.path.join(POSTS, body["file"]))
                if fp.startswith(os.path.realpath(POSTS) + os.sep) and os.path.isfile(fp):
                    reveal_path(fp)
                    return self._send(200, {"ok": True})
                return self._send(404, {"error": "no file"})
            rel = body.get("dir", "")
            full = os.path.realpath(os.path.join(POSTS, rel))
            if full.startswith(os.path.realpath(POSTS) + os.sep) and os.path.isdir(full):
                open_path(full)
                return self._send(200, {"ok": True})
            return self._send(404, {"error": "no folder"})
        self._send(404, {"error": "not found"})


if __name__ == "__main__":
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), H)
    print(f"@@BLOG@@ 운영실이 켜졌습니다: http://127.0.0.1:{PORT}")
    print("이 검은 창을 닫으면 운영실이 꺼집니다. 일이 끝날 때까지 열어 두세요.")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
