"""네이버 검색광고 키워드 도구 조회.

사용법:  python3 naver_keyword.py 스마트스토어
         python3 naver_keyword.py 스마트스토어 --top 30
         python3 naver_keyword.py 온누리상품권 마운자로 --expand
         python3 naver_keyword.py 온누리상품권 마운자로 --expand --save 포스팅/2026-10-13/키워드_마운자로.md

--expand: 네이버 자동완성 + 검색 결과의 '함께 많이 찾는' 목록을 모아
          키워드마다 검색량·광고를 붙인다 (황금비서 '연관 검색어' 박스와 같은 재료).
          검색광고 API의 연관 키워드는 광고 시장 기준이라 쓰지 않는다.
"""
import base64
import hashlib
import hmac
import json
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

BASE = "https://api.searchad.naver.com"
URI = "/keywordstool"
UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0 Safari/537.36"


def load_env():
    """같은 폴더의 .env 파일에서 값을 읽는다."""
    env = {}
    for line in (Path(__file__).parent / ".env").read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            env[k.strip()] = v.strip().strip('"').strip("'")
    return env


def signature(secret, timestamp, method, uri):
    msg = f"{timestamp}.{method}.{uri}"
    digest = hmac.new(secret.encode(), msg.encode(), hashlib.sha256).digest()
    return base64.b64encode(digest).decode()


def request(hint):
    """hint: 쉼표로 이은 키워드(최대 5개, 공백 없이). HTTPError는 그대로 올린다."""
    env = load_env()
    ts = str(int(time.time() * 1000))
    query = urllib.parse.urlencode({"hintKeywords": hint, "showDetail": "1"})
    req = urllib.request.Request(
        f"{BASE}{URI}?{query}",
        headers={
            "X-Timestamp": ts,
            "X-API-KEY": env["NAVER_API_KEY"],
            "X-Customer": env["NAVER_CUSTOMER_ID"],
            "X-Signature": signature(env["NAVER_SECRET_KEY"], ts, "GET", URI),
        },
    )
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.load(r)["keywordList"]


def search(keyword):
    try:
        return request(keyword.replace(" ", ""))
    except urllib.error.HTTPError as e:
        sys.exit(f"오류 {e.code}: {e.read().decode('utf-8', 'replace')}")


def to_num(v):
    # 검색량이 10 미만이면 "< 10" 문자열로 온다
    return v if isinstance(v, int) else 5


def fmt_row(name, x, src=""):
    pc, mo = to_num(x["monthlyPcQcCnt"]), to_num(x["monthlyMobileQcCnt"])
    clk = float(x.get("monthlyAvePcClkCnt") or 0) + float(x.get("monthlyAveMobileClkCnt") or 0)
    return (pc, mo, x["compIdx"], x.get("plAvgDepth", 0), clk,
            x.get("monthlyAveMobileCtr", 0), x.get("monthlyAvePcCtr", 0))


# ---------- 확장(--expand): 자동완성 + 함께 많이 찾는 ----------

def fetch(url, referer=None):
    headers = {"User-Agent": UA}
    if referer:
        headers["Referer"] = referer
    with urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=15) as r:
        return r.read().decode("utf-8", "replace")


def autocomplete(keyword):
    """네이버 검색창 자동완성 (비공식 주소, 바뀔 수 있음)."""
    q = urllib.parse.quote(keyword)
    url = (f"https://ac.search.naver.com/nx/ac?q={q}&con=0&frm=nv&ans=2&r_format=json"
           f"&r_enc=UTF-8&r_unicode=0&t_koreng=1&run=2&rev=4&q_enc=UTF-8&st=100")
    data = json.loads(fetch(url))
    return [item[0] for item in (data.get("items") or [[]])[0]]


def together(keyword):
    """검색 결과의 '함께 많이 찾는' (AI 검색어 제안, 사람마다 다를 수 있음)."""
    q = urllib.parse.quote(keyword)
    page_url = f"https://search.naver.com/search.naver?where=nexearch&query={q}"
    page = fetch(page_url)
    m = re.search(r'"apiURL":"(https://s\.search\.naver\.com/p/qra/[^"]+)"', page)
    if not m:
        return []
    api = m.group(1).encode().decode("unicode_escape")
    data = json.loads(fetch(api, referer=page_url))
    return [c["query"] for c in data.get("result", {}).get("contents", [])]


def measure(keywords):
    """키워드 목록의 검색량을 5개씩 묶어 조회한다. 결과: {공백제거·대문자 키: API 행}."""
    found = {}
    keys = list(dict.fromkeys(k.replace(" ", "") for k in keywords))
    for i in range(0, len(keys), 5):
        batch = keys[i:i + 5]
        for attempt in range(3):
            try:
                rows = request(",".join(batch))
                break
            except urllib.error.HTTPError as e:
                if e.code == 429 and attempt < 2:
                    time.sleep(5)
                    continue
                print(f"  (조회 실패 {e.code}: {', '.join(batch)})", file=sys.stderr)
                rows = []
                break
        wanted = {k.upper() for k in batch}
        for x in rows:
            key = x["relKeyword"].replace(" ", "").upper()
            if key in wanted:
                found[key] = x
        time.sleep(3)  # 연속 호출 시 429
    return found


def judge(total, ads, ctr, clk):
    """키워드 카드 잠정 기준 (하달 @@BLOG@@.md H-1). 광고 클릭이 월 10회 미만이면 CTR은 우연이라 보지 않는다."""
    size = "한 편" if total >= 1000 else ("소제목" if total >= 300 else "작음")
    try:
        ctr = float(ctr) if clk >= 10 else 0
    except (TypeError, ValueError):
        ctr = 0
    money = "상업형" if (ads or 0) >= 5 or ctr >= 2 else ("조회량형" if (ads or 0) <= 1 else "중간")
    return size, money


def expand(keyword, save=None):
    sources = {}
    try:
        for k in autocomplete(keyword):
            sources.setdefault(k, set()).add("자동완성")
    except Exception as e:
        print(f"  (자동완성 실패: {e})", file=sys.stderr)
    try:
        for k in together(keyword):
            sources.setdefault(k, set()).add("함께찾는")
    except Exception as e:
        print(f"  (함께 많이 찾는 실패: {e})", file=sys.stderr)
    sources.setdefault(keyword, set()).add("현재")
    if len(sources) == 1:
        print("  자동완성·함께 많이 찾는 둘 다 비었다. 키워드를 바꾸거나 띄어쓰기를 바꿔 본다.", file=sys.stderr)

    print(f"수집 {len(sources)}개, 검색량 조회 중 (5개씩, 호출 사이 3초)...", file=sys.stderr)
    data = measure(list(sources))

    rows = []
    for k, src in sources.items():
        x = data.get(k.replace(" ", "").upper())
        label = "+".join(s for s in ("현재", "자동완성", "함께찾는") if s in src)
        if x:
            pc, mo, comp, ads, clk, ctr_m, ctr_p = fmt_row(k, x)
            size, money = judge(pc + mo, ads, ctr_m, clk)
            rows.append((pc + mo, k, label, pc, mo, comp, ads, clk, ctr_m, ctr_p, size, money))
        else:
            rows.append((-1, k, label, None, None, "-", "-", None, "-", "-", "측정 안 됨", "-"))
    rows.sort(key=lambda r: r[0], reverse=True)

    lines = [f"# 키워드 확장: {keyword}",
             "",
             f"- 조회: {time.strftime('%Y-%m-%d %H:%M')} / 검색량은 최근 30일(검색광고 API), 10 미만은 5로 표기",
             "- 출처: 자동완성 = 검색창 드롭다운, 함께찾는 = 검색 결과 '함께 많이 찾는'(사람마다 다를 수 있음)",
             "- 판정(잠정): 합계 1,000 이상 한 편 / 300~1,000 소제목 / 상업형 = 광고수 5 이상 또는 모바일 CTR 2% 이상(광고 클릭 월 10회 이상일 때만)",
             "",
             "| 키워드 | 출처 | PC | 모바일 | 합계 | 경쟁 | 광고수 | 클릭 | CTR모바일 | CTR_PC | 쓰임 | 돈 유형 |",
             "|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for r in rows:
        total, k, label, pc, mo, comp, ads, clk, ctr_m, ctr_p, size, money = r
        if pc is None:
            lines.append(f"| {k} | {label} | - | - | - | - | - | - | - | - | {size} | - |")
        else:
            lines.append(f"| {k} | {label} | {pc:,} | {mo:,} | {total:,} | {comp} | {ads} | {clk:,.1f} | {ctr_m}% | {ctr_p}% | {size} | {money} |")
    ac = [k for k, s in sources.items() if "자동완성" in s]
    lines += ["", "## 자동완성 순서 (소제목 후보)", ""] + [f"{i}. {k}" for i, k in enumerate(ac, 1)]
    text = "\n".join(lines) + "\n"
    print(text)
    if save:
        p = Path(save)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text, encoding="utf-8")
        print(f"저장: {p}", file=sys.stderr)


def main():
    args = sys.argv[1:]
    if not args:
        sys.exit("사용법: python3 naver_keyword.py 키워드 [--top 개수] [--expand [--save 경로]]")
    top = 20
    if "--top" in args:
        i = args.index("--top")
        top = int(args[i + 1])
        del args[i:i + 2]
    save = None
    if "--save" in args:
        i = args.index("--save")
        save = args[i + 1]
        del args[i:i + 2]
    if "--expand" in args:
        args.remove("--expand")
        expand(" ".join(args), save)
        return
    rows = search(" ".join(args))
    rows.sort(key=lambda x: to_num(x["monthlyPcQcCnt"]) + to_num(x["monthlyMobileQcCnt"]), reverse=True)
    # 광고수 = 월평균 노출 광고 수(plAvgDepth), 클릭 = 광고 월평균 클릭 수(PC+모바일), CTR = 광고 클릭률(모바일·PC, %)
    print(f"{'키워드':<24}{'PC':>9}{'모바일':>9}{'합계':>9}  경쟁{'광고수':>6}{'클릭':>9}{'CTR모바일':>9}{'CTR_PC':>8}")
    for x in rows[:top]:
        pc, mo, comp, ads, clk, ctr_m, ctr_p = fmt_row(x["relKeyword"], x)
        print(f"{x['relKeyword']:<24}{pc:>9,}{mo:>9,}{pc + mo:>9,}  {comp}"
              f"{ads:>6}{clk:>9,.1f}{ctr_m:>8}%{ctr_p:>7}%")


if __name__ == "__main__":
    main()
