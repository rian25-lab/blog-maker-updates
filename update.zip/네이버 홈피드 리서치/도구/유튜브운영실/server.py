"""유튜브 운영실: 키워드나 링크 → 영상 보기 → 자막·Gemini 받아쓰기 → 내 PC 저장.

실행 ('네이버 홈피드 리서치' 폴더에서):
    python3 도구/유튜브운영실/server.py
그다음 브라우저에서 http://127.0.0.1:8787 을 연다.

키는 같은 폴더의 키.txt에 @@OWNER@@이 직접 넣는다(이 파일은 밖으로 보내지 않는다).
- YOUTUBE_API_KEY: 키워드 검색용(없으면 링크만 쓸 수 있다)
- GEMINI_API_KEY: 장면만·본문 텍스트·정돈용(없으면 무료 자막만 쓸 수 있다)
- GEMINI_MODEL: 비워 두면 키로 쓸 수 있는 최신 flash 모델을 고른다
"""

import json
import re
import sys
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
from datetime import date
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent  # 네이버 홈피드 리서치
KEY_FILE = HERE / "키.txt"
PORT = 8787

IS_WIN = sys.platform == "win32"
SAVE_AUTO = "(유튜브자료 — 채널별 자동)"
DOWNLOADS = "(다운로드 폴더)"

# 배포판(윈도우)은 자막 라이브러리를 lib/ 에 같이 넣어 보낸다
if (HERE / "lib").is_dir():
    sys.path.insert(0, str(HERE / "lib"))
sys.path.insert(0, str(HERE.parent))
import 자막받기 as jamak  # noqa: E402  (영상 ID 파싱·제목·자막 선택을 같이 쓴다)

# 유튜버 폴더가 아닌 본사 폴더는 저장 목록에서 뺀다
NOT_YOUTUBER = {
    "결과물", "발견함", "발행기록", "배포프로그램", "@@BLOG@@작업", "비교분석", "스레드",
    "실험결과", "외주", "자동화", "작업일지", "제목연구소", "지점성과", "하달", "홈판관측",
    "도구", "naver D2", "네이버 메이트", "유튜브자료",
}

PROMPTS = {
    "scene": (
        "이 영상에서 화면에 나타나는 글자만 시간순으로 적어라. 슬라이드 제목·문구, 자막 바, "
        "캡처 속 글자와 숫자가 대상이다. 음성은 적지 마라.\n"
        "형식: 한 줄에 하나, [mm:ss] 글자\n"
        "규칙: 숫자가 올라가는 애니메이션은 마지막 값만 적는다. 화면에 없는 것은 추측하지 않는다. "
        "개인 블로그 아이디처럼 일부만 보이는 식별 정보는 보이는 만큼만 적는다."
    ),
    "speech": (
        "이 영상의 음성을 들리는 그대로 받아써라. 요약하거나 문장을 다듬지 마라. "
        "군말과 반복도 남긴다. 화면 글자는 적지 마라.\n"
        "형식: 2~4문장마다 줄을 바꾸고 맨 앞에 [mm:ss]\n"
        "잘 안 들리는 곳은 [불명확]으로 표시한다."
    ),
    "tidy": (
        "이 영상을 챕터(화면에 챕터 표시가 있으면 그대로, 없으면 내용 흐름)별로 정리하라.\n"
        "각 구간은 [mm:ss] [화면 텍스트: …] 와 음성: … 을 짝지어 적는다. "
        "음성은 뜻을 바꾸지 말고 읽기 좋게 문장만 정돈한다. 빠뜨리지 않는다.\n"
        "숫자가 올라가는 애니메이션은 마지막 값만 적는다. 화면과 말이 다르면 둘 다 적는다. 추측 금지."
    ),
}

KIND_LABEL = {
    "transcript": ("자막", "txt", "유튜브 자막(youtube-transcript-api)"),
    "scene": ("장면", "md", "Gemini 받아쓰기 — 화면 글자만"),
    "speech": ("본문", "md", "Gemini 받아쓰기 — 음성 그대로"),
    "tidy": ("정돈", "md", "Gemini 받아쓰기 — 화면+음성 정돈(다듬어짐)"),
}


def read_keys():
    keys = {"YOUTUBE_API_KEY": "", "GEMINI_API_KEY": "", "GEMINI_MODEL": ""}
    if KEY_FILE.exists():
        for line in KEY_FILE.read_text(encoding="utf-8").splitlines():
            if "=" in line and not line.strip().startswith("#"):
                k, v = line.split("=", 1)
                if k.strip() in keys:
                    keys[k.strip()] = v.strip()
    return keys


def http_json(url, data=None, headers=None, timeout=30):
    body = json.dumps(data).encode() if data is not None else None
    req = urllib.request.Request(url, data=body, headers=headers or {})
    if body:
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.load(r)
    except urllib.error.HTTPError as e:
        try:
            msg = json.load(e).get("error", {}).get("message", "")
        except Exception:
            msg = ""
        raise RuntimeError(f"{e.code} {msg}".strip())


def iso_duration(s):
    m = re.fullmatch(r"P(?:(\d+)D)?T?(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?", s or "")
    if not m:
        return ""
    d, h, mi, se = (int(x or 0) for x in m.groups())
    return jamak.mmss(((d * 24 + h) * 60 + mi) * 60 + se)


# ---------- 기능 ----------

def search(q, order, period):
    key = read_keys()["YOUTUBE_API_KEY"]
    if not key:
        raise RuntimeError("키.txt에 YOUTUBE_API_KEY가 없습니다. 링크로는 바로 쓸 수 있습니다.")
    params = {
        "part": "snippet", "q": q, "type": "video", "maxResults": 12,
        "order": order if order in ("relevance", "date", "viewCount") else "relevance",
        "regionCode": "KR", "relevanceLanguage": "ko", "key": key,
    }
    if period in ("7", "30", "90", "365"):
        from datetime import datetime, timedelta, timezone
        after = datetime.now(timezone.utc) - timedelta(days=int(period))
        params["publishedAfter"] = after.strftime("%Y-%m-%dT%H:%M:%SZ")
    res = http_json("https://www.googleapis.com/youtube/v3/search?" + urllib.parse.urlencode(params))
    ids = [it["id"]["videoId"] for it in res.get("items", []) if it.get("id", {}).get("videoId")]
    if not ids:
        return []
    det = http_json("https://www.googleapis.com/youtube/v3/videos?" + urllib.parse.urlencode(
        {"part": "contentDetails,statistics,snippet", "id": ",".join(ids), "key": key}))
    out = []
    for v in det.get("items", []):
        sn = v["snippet"]
        out.append({
            "id": v["id"],
            "title": sn.get("title", ""),
            "channel": sn.get("channelTitle", ""),
            "published": sn.get("publishedAt", "")[:10],
            "duration": iso_duration(v.get("contentDetails", {}).get("duration")),
            "views": int(v.get("statistics", {}).get("viewCount", 0) or 0),
            "thumb": sn.get("thumbnails", {}).get("medium", {}).get("url", ""),
        })
    if params["order"] == "viewCount":  # 검색 API의 조회수순은 대략적이라 실제 조회수로 다시 정렬
        return sorted(out, key=lambda x: -x["views"])
    if params["order"] == "date":
        return sorted(out, key=lambda x: x["published"], reverse=True)
    order_ix = {i: n for n, i in enumerate(ids)}
    return sorted(out, key=lambda x: order_ix.get(x["id"], 99))


def video(link):
    vid = jamak.video_id(link)
    title, channel = jamak.video_info(vid)
    return {"id": vid, "title": title, "channel": channel}


def transcript(vid):
    try:
        t = jamak.pick_transcript(vid)
        snippets = t.fetch().snippets
    except (jamak.TranscriptsDisabled, jamak.NoTranscriptFound):
        raise RuntimeError("이 영상에는 한국어 자막이 없습니다(또는 유튜브가 막았습니다). "
                           "1·2·3 버튼(Gemini)을 쓰세요.")
    kind = "자동 생성" if t.is_generated else "수동"
    text = "\n".join(f"[{jamak.mmss(s.start)}] {s.text}" for s in snippets)
    return {"text": text, "note": f"{t.language} / {kind} 자막, {len(snippets)}줄"}


_model_cache = {}


def gemini_model(key, wanted):
    if wanted:
        return wanted
    if key in _model_cache:
        return _model_cache[key]
    res = http_json("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200",
                    headers={"x-goog-api-key": key})
    names = []
    for m in res.get("models", []):
        n = m["name"].split("/", 1)[-1]
        if ("generateContent" in m.get("supportedGenerationMethods", [])
                and "flash" in n and not re.search(r"lite|tts|image|live|audio|embed|thinking", n)):
            names.append(n)
    if not names:
        raise RuntimeError("쓸 수 있는 Gemini flash 모델을 찾지 못했습니다. 키.txt의 GEMINI_MODEL에 직접 적어 주세요.")

    def ver(n):
        nums = re.findall(r"\d+(?:\.\d+)?", n)
        return (float(nums[0]) if nums else 0, "preview" not in n and "exp" not in n, n)
    _model_cache[key] = max(names, key=ver)
    return _model_cache[key]


def gemini(vid, mode, extra):
    keys = read_keys()
    key = keys["GEMINI_API_KEY"]
    if not key:
        raise RuntimeError("키.txt에 GEMINI_API_KEY가 없습니다. 무료 '자막 받기'는 키 없이 됩니다.")
    model = gemini_model(key, keys["GEMINI_MODEL"])
    prompt = PROMPTS[mode]
    if extra.strip():
        prompt += "\n\n추가 요청: " + extra.strip()
    body = {"contents": [{"parts": [
        {"file_data": {"file_uri": f"https://www.youtube.com/watch?v={vid}"}},
        {"text": prompt},
    ]}]}
    res = http_json(f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
                    data=body, headers={"x-goog-api-key": key}, timeout=600)
    cands = res.get("candidates") or []
    if not cands:
        raise RuntimeError("Gemini가 답을 주지 않았습니다: " + json.dumps(res.get("promptFeedback", {}), ensure_ascii=False))
    text = "".join(p.get("text", "") for p in cands[0].get("content", {}).get("parts", []))
    note = f"Gemini {model}"
    if cands[0].get("finishReason") == "MAX_TOKENS":
        note += " · 길이 한도로 끝이 잘렸습니다"
    return {"text": text, "note": note, "model": model}


def folders():
    # 맥은 한글 폴더 이름을 자모로 풀어 돌려주므로(NFD) 합쳐서(NFC) 정렬한다
    names = sorted(unicodedata.normalize("NFC", p.name) for p in ROOT.iterdir()
                   if p.is_dir() and not p.name.startswith("."))
    names = [n for n in names if n not in NOT_YOUTUBER]
    return names + [SAVE_AUTO, DOWNLOADS]


def clean(s, n=40):
    return re.sub(r"[^\w가-힣]+", "", s or "")[:n]


def save(d):
    folder = d.get("folder", "")
    if folder == DOWNLOADS:
        target = Path.home() / "Downloads"
    elif folder == SAVE_AUTO:
        target = ROOT / "유튜브자료" / (clean(d.get("channel"), 30) or "채널미상")
        target.mkdir(parents=True, exist_ok=True)
    elif folder in folders():
        target = ROOT / folder
    else:
        raise RuntimeError("저장할 폴더를 고르세요.")
    label, ext, desc = KIND_LABEL.get(d.get("kind"), ("메모", "md", "직접 작성"))
    name = clean(d.get("name", "") or d.get("title", "") or d.get("id", ""))
    out = target / f"{date.today():%Y-%m-%d}_{name or 'video'}_{label}.{ext}"
    if out.exists():
        raise RuntimeError(f"같은 이름이 이미 있습니다(덮어쓰지 않음): {out.name}")
    header = [
        f"영상: https://www.youtube.com/watch?v={d.get('id', '')}",
        f"제목: {d.get('title') or '(확인 못 함)'}",
        f"채널: {d.get('channel') or '(확인 못 함)'}",
        f"종류: {desc}" + (f" / {d['note']}" if d.get("note") else ""),
        f"받은 날: {date.today():%Y-%m-%d} (유튜브 운영실)",
        "주의: 자동 자막·AI 받아쓰기는 잘못 듣거나 다듬은 곳이 있을 수 있다. 숫자는 영상과 대조한다.",
        "-" * 40,
    ]
    out.write_text("\n".join(header) + "\n" + d.get("text", "").rstrip() + "\n", encoding="utf-8")
    return {"path": str(out.relative_to(ROOT)) if folder != DOWNLOADS else str(out)}


# ---------- 서버 ----------

class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        sys.stderr.write("[운영실] " + fmt % args + "\n")

    def send(self, code, obj, ctype="application/json; charset=utf-8"):
        data = obj if isinstance(obj, bytes) else json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        u = urllib.parse.urlparse(self.path)
        if u.path in ("/", "/index.html"):
            return self.send(200, (HERE / "index.html").read_bytes(), "text/html; charset=utf-8")
        if u.path == "/api/status":
            k = read_keys()
            return self.send(200, {"youtube": bool(k["YOUTUBE_API_KEY"]), "gemini": bool(k["GEMINI_API_KEY"]),
                                   "folders": folders()})
        self.send(404, {"error": "없는 주소"})

    def do_POST(self):
        # 다른 사이트가 이 서버를 부르지 못하게 같은 주소에서 온 요청만 받는다
        origin = self.headers.get("Origin", "")
        if origin and origin not in (f"http://127.0.0.1:{PORT}", f"http://localhost:{PORT}"):
            return self.send(403, {"error": "허용되지 않은 요청"})
        try:
            n = int(self.headers.get("Content-Length", 0))
            d = json.loads(self.rfile.read(n) or b"{}")
            p = self.path
            if p == "/api/search":
                r = {"items": search(d.get("q", ""), d.get("order", ""), d.get("period", ""))}
            elif p == "/api/video":
                r = video(d.get("link", ""))
            elif p == "/api/transcript":
                r = transcript(d["id"])
            elif p == "/api/gemini":
                if d.get("mode") not in PROMPTS:
                    raise RuntimeError("모드가 잘못되었습니다.")
                r = gemini(d["id"], d["mode"], d.get("extra", ""))
            elif p == "/api/save":
                r = save(d)
            else:
                return self.send(404, {"error": "없는 주소"})
            self.send(200, r)
        except SystemExit as e:  # 자막받기.py의 안내 메시지
            self.send(400, {"error": str(e)})
        except Exception as e:
            self.send(400, {"error": str(e)})


def win_shortcut():
    """윈도우 배포판: 바탕화면에 '유튜브 운영실' 바로가기가 없으면 만든다.
    기존 설치자는 업데이트로 이 파일을 받으므로, 설치 프로그램 대신 여기서 만든다."""
    import base64
    import subprocess
    bat = ROOT / "유튜브 운영실 열기.bat"
    if not bat.exists():
        return
    ps = ("$d=[Environment]::GetFolderPath('Desktop');$p=Join-Path $d '유튜브 운영실.lnk';"
          "if(-not (Test-Path $p)){$s=New-Object -ComObject WScript.Shell;$l=$s.CreateShortcut($p);"
          f"$l.TargetPath='{bat}';$l.WorkingDirectory='{ROOT}';$l.Description='유튜브 영상을 글자로 받습니다';$l.Save()}}")
    enc = base64.b64encode(ps.encode("utf-16-le")).decode()
    try:
        subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-EncodedCommand", enc],
                       capture_output=True, timeout=20, creationflags=0x08000000)
    except Exception:
        pass


def main():
    if IS_WIN:
        win_shortcut()
    if not KEY_FILE.exists():
        KEY_FILE.write_text(
            "# @@OWNER@@이 직접 넣는 키. 이 파일은 남에게 보내지 않는다.\n"
            "YOUTUBE_API_KEY=\nGEMINI_API_KEY=\nGEMINI_MODEL=\n", encoding="utf-8")
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    print(f"유튜브 운영실: http://127.0.0.1:{PORT}  (끄려면 Ctrl+C)")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
