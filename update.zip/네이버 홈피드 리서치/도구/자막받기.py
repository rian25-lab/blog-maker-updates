"""유튜브 링크를 넣으면 자막을 받아 유튜버 폴더에 _자막.txt로 저장한다.

사용법 (이 폴더의 상위, 즉 '네이버 홈피드 리서치'에서 실행):
    python3 도구/자막받기.py <유튜브 링크> <유튜버 폴더> [짧은 제목]

예:
    python3 도구/자막받기.py "https://youtu.be/Oj9QehV63ng" 새벽리더 되는사람3가지
    → 새벽리더/2026-10-26_되는사람3가지_자막.txt

- 짧은 제목을 빼면 영상 제목을 그대로 쓴다(특수문자 제거, 40자까지).
- 한국어 수동 자막이 있으면 그것을, 없으면 한국어 자동 자막을 쓴다.
- 같은 이름 파일이 있으면 덮어쓰지 않고 멈춘다.
- 처음 한 번 설치: python3 -m pip install --user youtube-transcript-api
"""

import json
import re
import sys
import urllib.parse
import urllib.request
import warnings
from datetime import date

warnings.filterwarnings("ignore")  # 맥 기본 파이썬의 urllib3 SSL 경고 숨김
from pathlib import Path

NO_LIB = ("youtube-transcript-api가 없습니다. 먼저 설치하세요:\n"
          "  python3 -m pip install --user youtube-transcript-api")
try:
    from youtube_transcript_api import YouTubeTranscriptApi
    from youtube_transcript_api._errors import NoTranscriptFound, TranscriptsDisabled
except ImportError:  # 운영실은 라이브러리 없이도 켜지게 한다(자막 받기만 안 됨)
    YouTubeTranscriptApi = None

    class NoTranscriptFound(Exception):
        pass

    class TranscriptsDisabled(Exception):
        pass

ROOT = Path(__file__).resolve().parent.parent  # 네이버 홈피드 리서치


def video_id(link):
    """watch?v=, youtu.be/, shorts/, live/ 링크와 11자리 ID를 모두 받는다."""
    link = link.strip()
    if re.fullmatch(r"[\w-]{11}", link):
        return link
    u = urllib.parse.urlparse(link)
    if u.hostname and u.hostname.endswith("youtu.be"):
        return u.path.strip("/")[:11]
    q = urllib.parse.parse_qs(u.query)
    if "v" in q:
        return q["v"][0][:11]
    m = re.search(r"/(?:shorts|live|embed)/([\w-]{11})", u.path)
    if m:
        return m.group(1)
    sys.exit(f"링크에서 영상 ID를 찾지 못했습니다: {link}")


def video_info(vid):
    """제목·채널명 (oEmbed, 키 없이 됨). 실패해도 자막은 받는다."""
    url = ("https://www.youtube.com/oembed?format=json&url="
           + urllib.parse.quote(f"https://www.youtube.com/watch?v={vid}"))
    try:
        with urllib.request.urlopen(url, timeout=10) as r:
            d = json.load(r)
        return d.get("title", ""), d.get("author_name", "")
    except Exception:
        return "", ""


def pick_transcript(vid):
    if YouTubeTranscriptApi is None:
        raise RuntimeError(NO_LIB)
    tl = YouTubeTranscriptApi().list(vid)
    try:
        return tl.find_manually_created_transcript(["ko"])
    except NoTranscriptFound:
        return tl.find_generated_transcript(["ko"])


def mmss(sec):
    sec = int(sec)
    h, m, s = sec // 3600, sec % 3600 // 60, sec % 60
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"


def main():
    if len(sys.argv) < 3:
        sys.exit(__doc__)
    if YouTubeTranscriptApi is None:
        sys.exit(NO_LIB)
    link, folder_name = sys.argv[1], sys.argv[2]
    short = sys.argv[3] if len(sys.argv) > 3 else ""

    folder = ROOT / folder_name
    if not folder.is_dir():
        sys.exit(f"유튜버 폴더가 없습니다: {folder_name}\n"
                 "새 유튜버라면 폴더를 먼저 만드세요.")

    vid = video_id(link)
    title, channel = video_info(vid)

    try:
        t = pick_transcript(vid)
        snippets = t.fetch().snippets
    except (TranscriptsDisabled, NoTranscriptFound):
        sys.exit("이 영상에는 한국어 자막이 없습니다(또는 유튜브가 막았습니다).\n"
                 "Gemini 받아쓰기나 Vrew로 넘어가세요.")

    name = short or title or vid
    name = re.sub(r"[^\w가-힣]+", "", name)[:40] or vid
    out = folder / f"{date.today():%Y-%m-%d}_{name}_자막.txt"
    if out.exists():
        sys.exit(f"이미 있습니다(덮어쓰지 않음): {out.relative_to(ROOT)}")

    last = snippets[-1]
    kind = "자동 생성" if t.is_generated else "수동(업로더 작성)"
    header = [
        f"영상: https://www.youtube.com/watch?v={vid}",
        f"제목: {title or '(확인 못 함)'}",
        f"채널: {channel or '(확인 못 함)'}",
        f"자막: {t.language} / {kind}",
        f"길이: 약 {mmss(last.start + last.duration)}",
        f"받은 날: {date.today():%Y-%m-%d} (youtube-transcript-api)",
        "주의: 자동 자막은 잘못 들은 곳이 섞인다. 숫자는 영상이나 Gemini 판과 대조한다.",
        "-" * 40,
    ]
    lines = [f"[{mmss(s.start)}] {s.text}" for s in snippets]
    out.write_text("\n".join(header + lines) + "\n", encoding="utf-8")
    print(f"저장: {out.relative_to(ROOT)}  ({len(snippets)}줄, {kind})")


if __name__ == "__main__":
    main()
