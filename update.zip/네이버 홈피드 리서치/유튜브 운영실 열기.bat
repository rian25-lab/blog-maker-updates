@echo off
chcp 65001 >nul
setlocal
title 유튜브 운영실
set "HQ=%~dp0"
if "%HQ:~-1%"=="\" set "HQ=%HQ:~0,-1%"
set "PY=%HQ%\..\런타임\python\python.exe"
if not exist "%PY%" (
  echo 파이썬을 찾지 못했습니다: %PY%
  echo 설치 프로그램을 다시 실행해 주세요.
  pause
  exit /b 1
)
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
echo.
echo  유튜브 운영실을 켜는 중입니다...
echo  잠시 뒤 인터넷 창에 화면이 열립니다.
echo  이 검은 창은 닫지 말고 그대로 두세요. 닫으면 운영실이 꺼집니다.
echo.
start "" cmd /c "ping -n 4 127.0.0.1 >nul & start http://127.0.0.1:8787"
"%PY%" "%HQ%\도구\유튜브운영실\server.py"
echo.
echo  운영실이 꺼졌습니다. 이미 켜져 있다면 인터넷 창 주소창에 127.0.0.1:8787 을 입력하세요.
pause
